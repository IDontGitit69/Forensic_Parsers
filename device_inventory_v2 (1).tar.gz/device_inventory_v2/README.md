# Device Inventory → IRIS Asset Pipeline

Two-stage pipeline: collect hostname/IP from mounted evidence (any mix of
Windows/Linux/ESXi/Photon OS), then push results to DFIR-IRIS as case
Assets.

## Why two separate scripts

`device_inventory.py` runs **where the evidence is mounted** (your SIFT
workstation). `iris_asset_uploader.py` only needs network access to IRIS —
it can run on the same box or a different one. Same lesson learned from the
THOR forwarder: don't assume the evidence host and the IRIS host are the
same machine.

## Pipeline

```
mount_evidence.py (already have this)
        │
        ▼
.mount_state.json files under /mnt/IOC_SCAN/<host>/<image>/
        │
        ▼
device_inventory.py  →  device_inventory.json
   - reads mount_state.json directly (confirmed real structure)
   - detects OS family per partition, priority order:
       Windows -> ESXi -> Photon/vCenter -> generic Linux
   - Windows         -> windows_registry_reader.py (regipy, SYSTEM hive only)
   - ESXi            -> esxi_reader.py (vmware-#.log: Hostname=, IP=<ip> (<iface>))
   - Photon/vCenter  -> photon_reader.py (messages log: DEFAULT_IPV4) + linux_reader
                        for hostname (Photon follows standard /etc/hostname)
   - generic Linux   -> linux_reader.py (multi-distro)
   - multi-disk grouping post-pass: sibling images in the same hostname_dir
     inherit a resolved identity if they have none of their own (e.g. a
     non-OS data drive sitting alongside the OS drive)
        │
        ▼
iris_asset_uploader.py  →  POST /case/assets/add?cid=<case_id>
   - one real IRIS Asset per identified host
   - asset_ip formatted as one "IP (interface)" pair per line
```

## Install

```bash
pip install regipy requests --break-system-packages
```

(`regipy` is only needed on whichever machine runs `device_inventory.py`
against Windows images. `iris_asset_uploader.py` only needs `requests`.)

## Run

```bash
# On the evidence host (e.g. SIFT workstation):
python3 device_inventory.py --mount-base /mnt/IOC_SCAN --output inventory.json

# Review the output, especially anything with needs_manual_review: true
cat inventory.json

# Then, from anywhere with network access to IRIS:
python3 iris_asset_uploader.py \
    --inventory inventory.json \
    --iris-host https://<iris-host-ip>:8443 \
    --api-key <your-api-key> \
    --case-id <case-id> \
    --dry-run   # remove once the dry-run output looks right
```

## What's confirmed vs. what to verify on your own images

**Confirmed by direct testing in this conversation:**
- `mount_state.json` real structure (image_path, partitions list, etc.)
- IRIS `POST /case/assets/add?cid=X` — real endpoint, real required fields,
  tested live against a running v2.4.27 instance (created real assets)
- Real `assets_type` IDs: 3=Linux Server, 4=Linux Computer, 9=Windows
  Computer, 10=Windows Server, 11=Windows DC
- `analysis_status_id` must always be set explicitly (see "IRIS frontend
  bug" section below) — confirmed via live testing, not theoretical
- Windows registry reader tested against a real (intact) SYSTEM hive via
  `hivex` — correctly extracted hostname (`NIHEXB5`) and per-interface IPs
- Linux reader logic tested against synthetic Ubuntu/netplan, CentOS/legacy
  ifcfg structures — all correctly identified
- ESXi reader (`esxi_reader.py`) tested against a synthetic vmware-#.log
  fixture matching the real Hostname=/IP=<ip> (<iface>) format — correctly
  extracted hostname and both interface IPs
- Photon/vCenter reader (`photon_reader.py`) tested against a synthetic
  messages-log fixture with DEFAULT_IPV4 — correctly extracted the IP
- Multi-disk identity grouping tested against three scenarios directly:
  clean inheritance (sibling with no OS info inherits from resolved
  sibling), no-op (standalone host untouched), and genuine conflict
  (two siblings with DIFFERENT resolved hostnames — correctly refuses to
  guess which one a third unresolved sibling belongs to, flags for
  manual review instead)
- Unrecognized partition correctly flagged `needs_manual_review` rather
  than silently producing a wrong/empty asset
- Multi-line `asset_ip` formatting (`IP (interface)` per line) verified in
  dry-run output

**NOT tested against real ESXi/Photon evidence** — `esxi_reader.py` and
`photon_reader.py` were built and tested against synthetic log fixtures
matching the documented/provided line formats, not real vmware-#.log or
messages files pulled from an actual ESXi host or vCenter appliance image.
Run these against your real evidence and check the `ip_interface_pairs`
output looks sane before trusting it on a full case.

## Known limitations (by design, not oversights)

- **IP extraction from generic Linux config files is a regex sweep, not a
  real parser** for each format (YAML/INI/etc). It will return gateway and
  DNS addresses mixed in with the host's actual IP, and reports interface
  as `"unknown"` for these since the sweep can't reliably attribute an IP
  to a specific adapter — see the docstring on `_extract_ips_from_text()`
  in `linux_reader.py`. ESXi and Photon readers don't have this limitation
  since their source artifacts explicitly state the interface name/label.
- **Windows asset subtype (Computer/Server/DC) is guessed from hostname
  text** (`"DC"`/`"SRV"` substrings). Treat as a starting point to correct
  in the IRIS UI, not a confident classification.
- **ESXi/vCenter get no dedicated IRIS asset type** (none exists in this
  IRIS install) — created as "Linux - Server" with `is_esxi`/`photon-os`
  noted in description/tags, per explicit choice.
- **No create-or-update logic** — re-running the uploader against the same
  case will likely hit IRIS's unique-asset-name-per-case constraint and
  fail on duplicates rather than updating them.
- **Multi-disk grouping only fills gaps, never resolves conflicts.** If two
  images in the same hostname directory each independently resolve a
  DIFFERENT hostname, neither is touched and any other unresolved sibling
  in that group is flagged for manual review rather than guessed at.

## Corrupted SYSTEM hive recovery — tabled as a known edge case

A damaged/corrupted SYSTEM hive that fails to parse with `regipy` was also
tested against `hivex` (Red Hat's libguestfs hive library, generally more
damage-tolerant) using the same source file confirmed via hash match to a
direct mount copy (ruling out an export-artifact explanation). `hivex`
also failed to open it (`Operation not supported`). A from-scratch raw
byte-scraping approach was also attempted and found unreliable: registry
value names and their corresponding value data live in separate, linked
cells rather than adjacent bytes, so scraping without following that
structural link cannot reliably recover the value even when the name
anchor itself is found.

**Current status: tabled as a known edge case**, by deliberate choice, to
keep this a focused, real-world problem rather than an open-ended one. A
hive in this state most likely has genuine structural damage beyond what
any current approach in this project can recover. Partitions whose only
findable identity source is a hive in this state will be flagged
`needs_manual_review` with the specific parse error recorded, rather than
silently producing empty/wrong results. Revisit this only if it turns out
to affect more than a rare one-off image — diagnostic scripts used during
investigation (`test_raw_hive_scrape.py`, `diagnose_hive_encoding.py`,
`test_hivex.py` in this delivery) are kept for reference if that happens.

