#!/usr/bin/env python3
"""
photon_reader.py — Extract IP address from a vCenter Server Appliance
(Photon OS) 'messages' log via the DEFAULT_IPV4: <ip> line.

Per direct guidance: this is typically on the 4th partition (log_vg_log
volume group) under a 'vmware' directory, but configuration can vary, so
we search broadly under the mounted partition rather than assume one fixed
path -- same approach as the ESXi vmware.log search.

Hostname for Photon OS / vCenter appliances is still expected to come from
the standard Linux hostname sources (linux_reader.py already covers
/etc/hostname etc, and Photon OS follows that convention) -- this module
covers ONLY the IP address piece, since that's the part that needed a
special-cased artifact per direct guidance.
"""

from __future__ import annotations

import re
from pathlib import Path

DEFAULT_IPV4_RE = re.compile(r"DEFAULT_IPV4:\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)")


def find_messages_logs(mount_root: str) -> list[Path]:
    """
    Search broadly under the mounted partition for files named exactly
    'messages' (the standard syslog messages file name), rather than
    assuming a fixed path. There can be rotated copies (messages.1, etc)
    but per direct guidance we're looking for the current 'messages' file
    specifically containing the DEFAULT_IPV4 line.
    """
    root = Path(mount_root)
    if not root.exists():
        return []

    matches = []
    try:
        for path in root.rglob("messages"):
            if path.is_file():
                matches.append(path)
        # Also check rotated/compressed-adjacent variants in case the
        # current 'messages' file has already rotated out the relevant line
        for path in root.rglob("messages.*"):
            if path.is_file() and path.suffix not in (".gz", ".bz2", ".xz"):
                matches.append(path)
    except (PermissionError, OSError):
        pass

    return matches


def read_photon_ip(mount_root: str) -> dict:
    """
    Search for 'messages' log file(s) and extract DEFAULT_IPV4 value(s).
    Returns {"ip": str|None, "log_files_found": [...], "log_files_searched_count": int}
    """
    result = {"ip": None, "log_files_found": [], "log_files_searched_count": 0}

    messages_files = find_messages_logs(mount_root)
    result["log_files_searched_count"] = len(messages_files)

    found_ips = []
    for log_file in messages_files:
        try:
            content = log_file.read_text(errors="ignore")
        except OSError:
            continue
        matches = DEFAULT_IPV4_RE.findall(content)
        if matches:
            result["log_files_found"].append(str(log_file))
            found_ips.extend(matches)

    if found_ips:
        # Most recently-written occurrence is likely last in the file for
        # an append-only log; take the last match found across all files
        # as the most current value rather than majority vote (DHCP lease
        # could legitimately change over the log's lifetime, and we want
        # the latest, not the most repeated).
        result["ip"] = found_ips[-1]

    return result


def is_photon_partition(mount_root: str) -> bool:
    """
    Cheap check for whether this looks like it could be a Photon OS /
    vCenter appliance partition, used by the orchestrator to decide
    whether to try this reader at all. Looks for the standard Photon OS
    /etc/os-release PRETTY_NAME or VMware-specific marker paths, since a
    'messages' file alone isn't distinctive (every Linux box has one).
    """
    root = Path(mount_root)
    os_release = root / "etc" / "os-release"
    if os_release.exists():
        try:
            content = os_release.read_text(errors="ignore")
            if "photon" in content.lower() or "vmware" in content.lower():
                return True
        except OSError:
            pass

    # VCSA-specific marker paths as a secondary signal
    vcsa_markers = [
        root / "etc" / "vmware-vpx",
        root / "usr" / "lib" / "vmware-vpx",
    ]
    return any(m.exists() for m in vcsa_markers)
