#!/usr/bin/env python3
"""
linux_reader.py — Extract hostname and IP configuration from a mounted
Linux (or Linux-derived, e.g. ESXi console OS) partition, covering as many
distro/init-system conventions as practical without a live running system
to query.

Hostname sources tried in order (first non-empty wins):
  1. /etc/hostname                          (systemd-based: most modern
                                              Debian/Ubuntu/RHEL8+/Fedora)
  2. /etc/HOSTNAME                          (older SUSE/some embedded)
  3. /etc/sysconfig/network (HOSTNAME=...)  (RHEL/CentOS 6/7, older SysV)
  4. /etc/hosts                             (parse the first non-localhost
                                              FQDN entry as last resort --
                                              unreliable but better than
                                              nothing)

IP sources tried, results merged (a host can have multiple configs present
even if only one is "active" -- we report everything we find rather than
guess which was live at time of seizure):
  1. NetworkManager keyfiles:    /etc/NetworkManager/system-connections/*.nmconnection
  2. Netplan (Ubuntu 18.04+):    /etc/netplan/*.yaml
  3. Debian/Ubuntu legacy:       /etc/network/interfaces (+ /etc/network/interfaces.d/*)
  4. RHEL/CentOS legacy:         /etc/sysconfig/network-scripts/ifcfg-*
  5. systemd-networkd:           /etc/systemd/network/*.network

This list is not exhaustive of every possible Linux config mechanism that
has ever existed, but covers the common distro families requested. Anything
not matched falls through cleanly (empty ip list) rather than raising, and
the caller is expected to flag zero-IP results for manual review.
"""

from __future__ import annotations

import re
from pathlib import Path


def read_hostname(mount_root: str) -> str | None:
    root = Path(mount_root)

    etc_hostname = root / "etc" / "hostname"
    if etc_hostname.exists():
        try:
            content = etc_hostname.read_text(errors="ignore").strip()
            if content:
                return content.splitlines()[0].strip()
        except OSError:
            pass

    etc_HOSTNAME = root / "etc" / "HOSTNAME"
    if etc_HOSTNAME.exists():
        try:
            content = etc_HOSTNAME.read_text(errors="ignore").strip()
            if content:
                return content.splitlines()[0].strip()
        except OSError:
            pass

    sysconfig_network = root / "etc" / "sysconfig" / "network"
    if sysconfig_network.exists():
        try:
            for line in sysconfig_network.read_text(errors="ignore").splitlines():
                line = line.strip()
                if line.upper().startswith("HOSTNAME="):
                    val = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if val:
                        return val
        except OSError:
            pass

    # Last resort: /etc/hosts, look for the first FQDN-looking entry that
    # isn't localhost. Unreliable (hosts file can be stale/wrong) but better
    # than returning nothing.
    etc_hosts = root / "etc" / "hosts"
    if etc_hosts.exists():
        try:
            for line in etc_hosts.read_text(errors="ignore").splitlines():
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                parts = line.split()
                if len(parts) < 2:
                    continue
                ip, *names = parts
                if ip in ("127.0.0.1", "::1", "127.0.1.1"):
                    continue
                for name in names:
                    if "." in name:  # looks like an FQDN
                        return name
        except OSError:
            pass

    return None


_IP_PATTERN = re.compile(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:/\d{1,2})?\b")


def _extract_ips_from_text(text: str) -> set[str]:
    """
    Pull IPv4 addresses out of arbitrary config text, filtering obvious junk.

    LIMITATION: this is a regex sweep over the raw file content, not a
    structured parser for each config format's actual schema (YAML for
    netplan, INI for NetworkManager keyfiles, etc). It cannot distinguish
    a host's own address from a gateway, DNS server, or netmask written as
    a dotted-quad in the same file -- all of those will be returned
    together. For netplan/NetworkManager specifically, "addresses:" lines
    are the host's own IP and "gateway4/gateway"-prefixed lines are not,
    but this function does not parse line context to separate them. Treat
    the returned list as "every IP-shaped string found in this file," and
    expect to see gateway addresses mixed in -- this is a known tradeoff
    for covering many config formats without writing a dedicated parser
    for each one.
    """
    found = set()
    for match in _IP_PATTERN.finditer(text):
        ip = match.group(1)
        # Filter common placeholder/junk values that aren't real host IPs
        if ip in ("0.0.0.0", "255.255.255.255", "127.0.0.1"):
            continue
        octets = ip.split(".")
        if all(o.isdigit() and 0 <= int(o) <= 255 for o in octets):
            found.add(ip)
    return found


def read_ips(mount_root: str) -> list[str]:
    root = Path(mount_root)
    ips: set[str] = set()

    # 1. NetworkManager keyfiles
    nm_dir = root / "etc" / "NetworkManager" / "system-connections"
    if nm_dir.exists():
        for f in nm_dir.glob("*"):
            if f.is_file():
                try:
                    ips |= _extract_ips_from_text(f.read_text(errors="ignore"))
                except OSError:
                    continue

    # 2. Netplan
    netplan_dir = root / "etc" / "netplan"
    if netplan_dir.exists():
        for f in netplan_dir.glob("*.yaml"):
            try:
                ips |= _extract_ips_from_text(f.read_text(errors="ignore"))
            except OSError:
                continue

    # 3. Debian/Ubuntu legacy interfaces
    legacy_if = root / "etc" / "network" / "interfaces"
    if legacy_if.exists():
        try:
            ips |= _extract_ips_from_text(legacy_if.read_text(errors="ignore"))
        except OSError:
            pass
    legacy_if_d = root / "etc" / "network" / "interfaces.d"
    if legacy_if_d.exists():
        for f in legacy_if_d.glob("*"):
            if f.is_file():
                try:
                    ips |= _extract_ips_from_text(f.read_text(errors="ignore"))
                except OSError:
                    continue

    # 4. RHEL/CentOS ifcfg-* scripts
    ifcfg_dir = root / "etc" / "sysconfig" / "network-scripts"
    if ifcfg_dir.exists():
        for f in ifcfg_dir.glob("ifcfg-*"):
            try:
                content = f.read_text(errors="ignore")
                for line in content.splitlines():
                    line = line.strip()
                    if line.upper().startswith("IPADDR"):
                        val = line.split("=", 1)[1].strip().strip('"').strip("'")
                        ips |= _extract_ips_from_text(val)
            except OSError:
                continue

    # 5. systemd-networkd
    networkd_dir = root / "etc" / "systemd" / "network"
    if networkd_dir.exists():
        for f in networkd_dir.glob("*.network"):
            try:
                ips |= _extract_ips_from_text(f.read_text(errors="ignore"))
            except OSError:
                continue

    return sorted(ips)


def detect_distro(mount_root: str) -> str:
    """
    Best-effort distro/OS identification string for the asset description.
    Tries /etc/os-release first (the modern standard), falls back to a few
    distro-specific marker files, then a generic 'Linux' if nothing matches.
    """
    root = Path(mount_root)

    os_release = root / "etc" / "os-release"
    if os_release.exists():
        try:
            content = os_release.read_text(errors="ignore")
            for line in content.splitlines():
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
        except OSError:
            pass

    # ESXi doesn't have a standard /etc/os-release in older versions;
    # /etc/vmware-release is the classic marker.
    vmware_release = root / "etc" / "vmware-release"
    if vmware_release.exists():
        try:
            content = vmware_release.read_text(errors="ignore").strip()
            if content:
                return content
        except OSError:
            pass

    redhat_release = root / "etc" / "redhat-release"
    if redhat_release.exists():
        try:
            content = redhat_release.read_text(errors="ignore").strip()
            if content:
                return content
        except OSError:
            pass

    debian_version = root / "etc" / "debian_version"
    if debian_version.exists():
        try:
            content = debian_version.read_text(errors="ignore").strip()
            if content:
                return f"Debian {content}"
        except OSError:
            pass

    return "Linux (distro unidentified)"


def is_esxi(mount_root: str) -> bool:
    """
    Detect ESXi specifically, since it's a Linux-derived but distinct OS
    that should be tagged/described differently per the chosen asset
    convention (Linux - Server type, but tagged/described as ESXi).
    """
    root = Path(mount_root)
    markers = [
        root / "etc" / "vmware-release",
        root / "etc" / "vmware",
        root / "bin" / "esxcli",
        root / "sbin" / "vmkernel",
    ]
    return any(m.exists() for m in markers)


def read_linux_info(mount_root: str) -> dict:
    return {
        "hostname": read_hostname(mount_root),
        "ips": read_ips(mount_root),
        "distro": detect_distro(mount_root),
        "is_esxi": is_esxi(mount_root),
    }
