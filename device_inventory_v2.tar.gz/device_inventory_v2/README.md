# Device Inventory → IRIS Asset Pipeline

Two-stage pipeline: collect hostname/IP from mounted evidence (any mix of
Windows/Linux/ESXi), then push results to DFIR-IRIS as case Assets.

## Why two separate scripts

`device_inventory.py` runs **where the evidence is mounted** (your SIFT
workstation). `iris_asset_uploader.py` only needs network access to IRIS —
it can run on the same box or a different one. Same lesson learned from the
THOR forwarder: don't assume the evidence host and the IRIS host are the
same machine.

## Pipeline

```
mount_evidence.py (already have this)
        │
        ▼
.mount_state.json files under /mnt/IOC_SCAN/<host>/<image>/
        │
        ▼
device_inventory.py  →  device_inventory.json
   - reads mount_state.json directly (confirmed real structure)
   - detects OS family per partition (Windows dir vs etc+bin+usr)
   - Windows → windows_registry_reader.py (regipy, SYSTEM hive only)
   - Linux/ESXi → linux_reader.py (multi-distro + ESXi detection)
        │
        ▼
iris_asset_uploader.py  →  POST /case/assets/add?cid=<case_id>
   - one real IRIS Asset per identified host
```

## Install

```bash
pip install regipy requests --break-system-packages
```

(`regipy` is only needed on whichever machine runs `device_inventory.py`
against Windows images. `iris_asset_uploader.py` only needs `requests`.)

## Run

```bash
# On the evidence host (e.g. SIFT workstation):
python3 device_inventory.py --mount-base /mnt/IOC_SCAN --output inventory.json

# Review the output, especially anything with needs_manual_review: true
cat inventory.json

# Then, from anywhere with network access to IRIS:
python3 iris_asset_uploader.py \
    --inventory inventory.json \
    --iris-host https://<iris-host-ip>:8443 \
    --api-key <your-api-key> \
    --case-id <case-id> \
    --dry-run   # remove once the dry-run output looks right
```

## What's confirmed vs. what to verify on your own images

**Confirmed by direct testing in this conversation:**
- `mount_state.json` real structure (image_path, partitions list, etc.)
- IRIS `POST /case/assets/add?cid=X` — real endpoint, real required fields,
  tested live against a running v2.4.27 instance via curl (created asset_id 1)
- Real `assets_type` IDs: 3=Linux Server, 4=Linux Computer, 9=Windows
  Computer, 10=Windows Server, 11=Windows DC
- Linux reader logic tested against synthetic Ubuntu/netplan, CentOS/legacy
  ifcfg, and ESXi-style mount structures — all three correctly identified
- Unrecognized partition correctly flagged `needs_manual_review` rather
  than silently producing a wrong/empty asset

**NOT yet tested against a real Windows image or real regipy parse** —
`windows_registry_reader.py` was written against well-documented, standard
registry paths (`ControlSet00N\Control\ComputerName\ComputerName`,
`...\Services\Tcpip\Parameters\Interfaces\{GUID}`) and regipy's documented
API, but has not been run against an actual SYSTEM hive in this session.
**Test this against one of your real Windows images before trusting it on
a full case** — if regipy's actual return shapes differ from what the code
assumes (e.g. `value.value` not being a plain string/list the way expected),
it will most likely raise inside `read_windows_info()`, which
`device_inventory.py` catches and flags as `needs_manual_review` rather
than crashing the whole run — but verify a real hit looks correct, not just
that it doesn't crash.

## Known limitations (by design, not oversights)

- **IP extraction from Linux config files is a regex sweep, not a real
  parser** for each format (YAML/INI/etc). It will return gateway and DNS
  addresses mixed in with the host's actual IP — see the docstring on
  `_extract_ips_from_text()` in `linux_reader.py`. Expect to eyeball the
  `ips` list per host rather than trust it's exactly and only the host's
  own addresses.
- **Windows asset subtype (Computer/Server/DC) is guessed from hostname
  text** (`"DC"`/`"SRV"` substrings) since there's no reliable way to tell
  workstation vs. server from the registry alone without deeper role
  inspection. Treat `asset_type_id` for Windows hosts as a starting point
  to correct in the IRIS UI, not a confident classification.
- **ESXi/vCenter get no dedicated IRIS asset type** (none exists in this
  IRIS install) — they're created as "Linux - Server" with `is_esxi` noted
  in the description and an `esxi` tag, per your explicit choice.
- **No create-or-update logic** — re-running the uploader against the same
  case will likely hit IRIS's unique-asset-name-per-case constraint
  (`is_unique_for_cid`, confirmed in the real route source) and fail on
  duplicates rather than updating them. If you need to re-run after fixing
  a flagged record, either delete the old asset in IRIS first or extend
  `iris_asset_uploader.py` to check for an existing asset by name first.
