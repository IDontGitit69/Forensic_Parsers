#!/usr/bin/env python3
"""
device_inventory.py — Walk mount_evidence.py's mount tree, detect each
image's OS, extract hostname/IP via the appropriate reader, and produce
structured inventory records ready for IRIS asset creation.

Reads directly from .mount_state.json files written by mount_evidence.py
(confirmed real structure: image_path, mount_base, partitions, etc.) rather
than independently discovering mounted filesystems.

Usage:
  python3 device_inventory.py --mount-base /mnt/IOC_SCAN --output inventory.json
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path

from linux_reader import read_linux_info
from windows_registry_reader import find_system_hive, read_windows_info, WindowsRegistryError

STATE_FILE = ".mount_state.json"

# IRIS asset_type_id values, confirmed live against a real v2.4.27 instance's
# assets_type table (see project notes -- query: SELECT asset_id, asset_name
# FROM assets_type). No dedicated ESXi/VMware type exists, so ESXi hosts use
# "Linux - Server" with is_esxi flagged separately for description/tags.
ASSET_TYPE_LINUX_SERVER = 3
ASSET_TYPE_LINUX_COMPUTER = 4
ASSET_TYPE_WINDOWS_COMPUTER = 9
ASSET_TYPE_WINDOWS_SERVER = 10
ASSET_TYPE_WINDOWS_DC = 11
ASSET_TYPE_UNKNOWN = None


@dataclass
class InventoryRecord:
    source_hostname_dir: str       # the top-level folder name under mount_base
    image_path: str
    partition_mount: str
    os_family: str = "unknown"     # "windows" | "linux" | "unknown"
    hostname: str | None = None
    ips: list = field(default_factory=list)
    distro_or_os_info: str = ""
    is_esxi: bool = False
    asset_type_id: int | None = None
    needs_manual_review: bool = False
    review_reason: str = ""


def detect_os_family(partition_mount: str) -> str:
    """
    Cheap OS-family detection before dispatching to the right reader: look
    for telltale top-level directories. Avoids running the (slower, and for
    Windows, hive-parsing) reader against a partition that obviously isn't
    that OS.
    """
    root = Path(partition_mount)
    if not root.exists():
        return "unknown"

    try:
        entries = {e.name.lower() for e in root.iterdir()}
    except (OSError, PermissionError):
        return "unknown"

    if "windows" in entries:
        return "windows"
    if "etc" in entries and ("bin" in entries or "usr" in entries or "var" in entries):
        return "linux"
    return "unknown"


def classify_windows_asset_type(hostname: str | None) -> int:
    """
    Best-effort Windows asset subtype from hostname conventions alone (no
    reliable way to distinguish workstation/server/DC from the registry
    without deeper inspection of installed roles, which is out of scope
    here). Defaults to generic Windows Computer; this is a coarse guess,
    not a confident classification -- worth eyeballing in IRIS afterward.
    """
    if not hostname:
        return ASSET_TYPE_WINDOWS_COMPUTER
    name_upper = hostname.upper()
    if "DC" in name_upper or "DOMAIN" in name_upper:
        return ASSET_TYPE_WINDOWS_DC
    if "SRV" in name_upper or "SERVER" in name_upper:
        return ASSET_TYPE_WINDOWS_SERVER
    return ASSET_TYPE_WINDOWS_COMPUTER


def process_partition(hostname_dir: str, image_path: str, partition_mount: str) -> InventoryRecord:
    record = InventoryRecord(
        source_hostname_dir=hostname_dir,
        image_path=image_path,
        partition_mount=partition_mount,
    )

    os_family = detect_os_family(partition_mount)
    record.os_family = os_family

    if os_family == "windows":
        system_hive = find_system_hive(partition_mount)
        if not system_hive:
            record.needs_manual_review = True
            record.review_reason = "Windows partition detected but SYSTEM hive not found"
            return record
        try:
            info = read_windows_info(system_hive)
        except WindowsRegistryError as e:
            record.needs_manual_review = True
            record.review_reason = f"SYSTEM hive parse failed: {e}"
            return record

        record.hostname = info.get("hostname")
        record.ips = info.get("ips", [])
        record.distro_or_os_info = "Windows"
        record.asset_type_id = classify_windows_asset_type(record.hostname)

        if not record.hostname:
            record.needs_manual_review = True
            record.review_reason = "Hostname not found in SYSTEM hive (ComputerName value missing)"
        if not record.ips:
            record.needs_manual_review = True
            record.review_reason += "; No IPs found in Tcpip interfaces" if record.review_reason else "No IPs found in Tcpip interfaces"

    elif os_family == "linux":
        info = read_linux_info(partition_mount)
        record.hostname = info.get("hostname")
        record.ips = info.get("ips", [])
        record.distro_or_os_info = info.get("distro", "")
        record.is_esxi = info.get("is_esxi", False)
        record.asset_type_id = ASSET_TYPE_LINUX_SERVER  # default to server; see note below

        if not record.hostname:
            record.needs_manual_review = True
            record.review_reason = "Hostname not found via any known Linux convention"
        if not record.ips:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}No IPs found via any known Linux network config convention"

    else:
        record.needs_manual_review = True
        record.review_reason = "Could not determine OS family from partition contents (no Windows/ dir, no Linux etc+bin+usr structure)"

    return record


def discover_partitions(mount_base: Path) -> list[tuple]:
    """
    Read every .mount_state.json under mount_base and return
    (hostname_dir, image_path, partition_mount) tuples for every partition
    listed -- confirmed real structure: state["partitions"] is a list of
    mount point path strings.
    """
    results = []
    state_files = sorted(mount_base.glob("*/*/" + STATE_FILE))

    for sf in state_files:
        try:
            state = json.loads(sf.read_text())
        except (json.JSONDecodeError, OSError) as e:
            print(f"[!] Skipping unreadable state file {sf}: {e}", file=sys.stderr)
            continue

        rel = sf.parent.relative_to(mount_base)
        hostname_dir = rel.parts[0] if rel.parts else "unknown"
        image_path = state.get("image_path", "unknown")

        for partition_mount in state.get("partitions", []):
            results.append((hostname_dir, image_path, partition_mount))

    return results


def main():
    parser = argparse.ArgumentParser(description="Inventory mounted evidence for hostname/IP, multi-OS")
    parser.add_argument("--mount-base", default="/mnt/IOC_SCAN")
    parser.add_argument("--output", default="device_inventory.json")
    args = parser.parse_args()

    mount_base = Path(args.mount_base)
    if not mount_base.exists():
        print(f"[ERROR] Mount base does not exist: {mount_base}", file=sys.stderr)
        sys.exit(1)

    partitions = discover_partitions(mount_base)
    if not partitions:
        print(f"[!] No mounted partitions found under {mount_base} (no .mount_state.json files)", file=sys.stderr)
        sys.exit(1)

    records = []
    for hostname_dir, image_path, partition_mount in partitions:
        print(f"[*] Processing {hostname_dir} :: {partition_mount}")
        record = process_partition(hostname_dir, image_path, partition_mount)
        records.append(record)
        status = "OK" if not record.needs_manual_review else f"NEEDS REVIEW: {record.review_reason}"
        print(f"    os={record.os_family} hostname={record.hostname} ips={record.ips} [{status}]")

    output_path = Path(args.output)
    output_path.write_text(json.dumps([asdict(r) for r in records], indent=2))

    review_count = sum(1 for r in records if r.needs_manual_review)
    print(f"\n[✓] Inventoried {len(records)} partition(s). {review_count} flagged for manual review.")
    print(f"    Output: {output_path}")


if __name__ == "__main__":
    main()
