#!/usr/bin/env python3
"""
device_inventory.py — Walk mount_evidence.py's mount tree, detect each
image's OS, extract hostname/IP via the appropriate reader, and produce
structured inventory records ready for IRIS asset creation.

Reads directly from .mount_state.json files written by mount_evidence.py
(confirmed real structure: image_path, mount_base, partitions, etc.) rather
than independently discovering mounted filesystems.

Reader dispatch order per partition:
  1. Windows (SYSTEM hive present)              -> windows_registry_reader
  2. ESXi (vmware-#.log present)                 -> esxi_reader
  3. Photon OS / vCenter appliance (os-release   -> photon_reader (IP only)
     mentions photon/vmware, or vcsa markers)       + linux_reader (hostname)
  4. Generic Linux                               -> linux_reader

Multi-disk grouping: per direct guidance, a single "hostname directory"
under mount_base can contain multiple images (e.g. a Windows server's OS
drive + a separate data drive). If one image in a hostname directory
resolves a hostname/IP and a sibling image in the SAME hostname directory
doesn't (e.g. the second image isn't a bootable OS volume at all), the
sibling inherits the resolved identity instead of being flagged as a
separate unknown host. This is a post-pass over all records, run after
every partition has been individually processed.

Usage:
  python3 device_inventory.py --mount-base /mnt/IOC_SCAN --output inventory.json
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, asdict, field
from pathlib import Path

from linux_reader import read_linux_info
from windows_registry_reader import find_system_hive, read_windows_info, WindowsRegistryError
from esxi_reader import is_esxi_partition, read_esxi_info
from photon_reader import is_photon_partition, read_photon_ip

STATE_FILE = ".mount_state.json"

# IRIS asset_type_id values, confirmed live against a real v2.4.27 instance's
# assets_type table (see project notes -- query: SELECT asset_id, asset_name
# FROM assets_type). No dedicated ESXi/VMware type exists, so ESXi hosts use
# "Linux - Server" with is_esxi flagged separately for description/tags.
ASSET_TYPE_LINUX_SERVER = 3
ASSET_TYPE_LINUX_COMPUTER = 4
ASSET_TYPE_WINDOWS_COMPUTER = 9
ASSET_TYPE_WINDOWS_SERVER = 10
ASSET_TYPE_WINDOWS_DC = 11
ASSET_TYPE_UNKNOWN = None


@dataclass
class InventoryRecord:
    source_hostname_dir: str       # the top-level folder name under mount_base
    image_path: str
    partition_mount: str
    os_family: str = "unknown"     # "windows" | "linux" | "esxi" | "photon" | "unknown"
    hostname: str | None = None
    ips: list = field(default_factory=list)
    ip_interface_pairs: list = field(default_factory=list)  # [(ip, interface), ...]
    distro_or_os_info: str = ""
    is_esxi: bool = False
    asset_type_id: int | None = None
    needs_manual_review: bool = False
    review_reason: str = ""
    identity_inherited_from: str | None = None  # set during the grouping pass


def discover_images(mount_base: Path) -> list[dict]:
    """
    Read every .mount_state.json under mount_base and group results by
    IMAGE (not by individual partition) -- confirmed real structure:
    state["partitions"] is a list of mount point path strings, and one
    state file = one image, which may list multiple partitions.

    Returns a list of dicts: {"hostname_dir": str, "image_path": str,
    "partition_mounts": [str, ...]}.

    This grouping matters because, per direct guidance, ESXi images
    commonly mount as MULTIPLE partitions (boot bank, store, scratch,
    etc), and the vmware-#.log files needed to identify the host might
    live on a different partition than whichever one a naive per-partition
    walk happens to inspect first. Detection has to consider every
    partition belonging to the same image together, not in isolation.
    """
    images = []
    state_files = sorted(mount_base.glob("*/*/" + STATE_FILE))

    for sf in state_files:
        try:
            state = json.loads(sf.read_text())
        except (json.JSONDecodeError, OSError) as e:
            print(f"[!] Skipping unreadable state file {sf}: {e}", file=sys.stderr)
            continue

        rel = sf.parent.relative_to(mount_base)
        hostname_dir = rel.parts[0] if rel.parts else "unknown"
        image_path = state.get("image_path", "unknown")
        partition_mounts = state.get("partitions", [])

        if partition_mounts:
            images.append({
                "hostname_dir": hostname_dir,
                "image_path": image_path,
                "partition_mounts": partition_mounts,
            })

    return images


def detect_os_family(partition_mounts: list) -> tuple:
    """
    Detect OS family for an IMAGE (which may have multiple mounted
    partitions), checking ALL of its partitions together rather than one
    in isolation.

    Returns (os_family, primary_partition_mount) where primary_partition_mount
    is whichever partition should be used as the "main" one for readers that
    only need a single root (Windows: the partition with the Windows dir;
    generic Linux: the partition with the etc dir). ESXi/Photon readers
    search across ALL partition_mounts themselves (see esxi_reader.py /
    photon_reader.py), since their relevant artifacts may be scattered
    across multiple partitions of the same image.

    Detection order, checked across every partition of the image:
      1. Windows  -- any partition has a top-level Windows/ dir
      2. ESXi     -- any partition has a vmware-#.log ANYWHERE under it
                     (no etc+bin+usr gate -- ESXi's on-disk layout doesn't
                     necessarily look like a conventional Unix tree at the
                     top level of any single partition, so gating this
                     check behind that structure was the original bug)
      3. Photon   -- any partition's os-release mentions photon/vmware,
                     or has vcsa marker paths
      4. Generic Linux -- any partition has etc+bin/usr/var at its top level
      5. unknown  -- none of the above matched on any partition
    """
    windows_partition = None
    linux_like_partition = None

    for pm in partition_mounts:
        root = Path(pm)
        if not root.exists():
            continue
        try:
            entries = {e.name.lower() for e in root.iterdir()}
        except (OSError, PermissionError):
            continue

        if "windows" in entries and windows_partition is None:
            windows_partition = pm

        looks_linux = "etc" in entries and ("bin" in entries or "usr" in entries or "var" in entries)
        if looks_linux and linux_like_partition is None:
            linux_like_partition = pm

    if windows_partition:
        return "windows", windows_partition

    # ESXi/Photon checks run across ALL partitions of the image, unconditionally
    # -- no top-level etc+bin+usr gate. This is the actual fix: ESXi's vmware-#.log
    # (and Photon's messages log) can exist on a partition that doesn't look like
    # a conventional Unix tree at its top level, or on a DIFFERENT partition than
    # whichever one happens to look Linux-shaped.
    for pm in partition_mounts:
        if is_esxi_partition(pm):
            # Use the linux-like partition as primary if one exists (for
            # distro string / fallback purposes), else just the first
            # partition that triggered the ESXi match.
            return "esxi", (linux_like_partition or pm)

    for pm in partition_mounts:
        if is_photon_partition(pm):
            return "photon", (linux_like_partition or pm)

    if linux_like_partition:
        return "linux", linux_like_partition

    return "unknown", (partition_mounts[0] if partition_mounts else None)


def classify_windows_asset_type(hostname: str | None) -> int:
    """
    Best-effort Windows asset subtype from hostname conventions alone (no
    reliable way to distinguish workstation/server/DC from the registry
    without deeper inspection of installed roles, which is out of scope
    here). Defaults to generic Windows Computer; this is a coarse guess,
    not a confident classification -- worth eyeballing in IRIS afterward.
    """
    if not hostname:
        return ASSET_TYPE_WINDOWS_COMPUTER
    name_upper = hostname.upper()
    if "DC" in name_upper or "DOMAIN" in name_upper:
        return ASSET_TYPE_WINDOWS_DC
    if "SRV" in name_upper or "SERVER" in name_upper:
        return ASSET_TYPE_WINDOWS_SERVER
    return ASSET_TYPE_WINDOWS_COMPUTER


def process_image(hostname_dir: str, image_path: str, partition_mounts: list) -> InventoryRecord:
    """
    Process one IMAGE (which may have multiple mounted partitions). The
    returned record's partition_mount field holds whichever partition was
    selected as "primary" by detect_os_family -- individual reader
    functions for ESXi/Photon search across ALL partition_mounts
    internally, since their relevant artifacts may not live on the
    primary partition at all (see detect_os_family docstring).
    """
    os_family, primary_partition = detect_os_family(partition_mounts)

    record = InventoryRecord(
        source_hostname_dir=hostname_dir,
        image_path=image_path,
        partition_mount=primary_partition or (partition_mounts[0] if partition_mounts else "unknown"),
        os_family=os_family,
    )

    if os_family == "windows":
        system_hive = find_system_hive(primary_partition)
        if not system_hive:
            record.needs_manual_review = True
            record.review_reason = "Windows partition detected but SYSTEM hive not found"
            return record
        try:
            info = read_windows_info(system_hive)
        except WindowsRegistryError as e:
            record.needs_manual_review = True
            record.review_reason = f"SYSTEM hive parse failed: {e}"
            return record

        record.hostname = info.get("hostname")
        record.ips = info.get("ips", [])
        record.ip_interface_pairs = info.get("ip_interface_pairs", [])
        record.distro_or_os_info = "Windows"
        record.asset_type_id = classify_windows_asset_type(record.hostname)

        if not record.hostname:
            record.needs_manual_review = True
            record.review_reason = "Hostname not found in SYSTEM hive (ComputerName value missing)"
        if not record.ips:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}No IPs found in Tcpip interfaces"

    elif os_family == "esxi":
        # Search ALL partitions of this image, not just the primary one --
        # vmware-#.log may live on a different partition (boot/store/scratch)
        # than whichever one was picked as primary.
        esxi_info = read_esxi_info(partition_mounts)
        record.hostname = esxi_info.hostname
        record.ips = [ip for ip, _iface in esxi_info.ip_interface_pairs]
        record.ip_interface_pairs = esxi_info.ip_interface_pairs
        record.distro_or_os_info = "VMware ESXi"
        record.is_esxi = True
        record.asset_type_id = ASSET_TYPE_LINUX_SERVER  # per chosen convention, no dedicated ESXi type

        if not esxi_info.log_files_found:
            record.needs_manual_review = True
            record.review_reason = (
                f"ESXi detected but no vmware-#.log contained Hostname=/IP= lines "
                f"({esxi_info.log_files_searched_count} log file(s) searched across "
                f"{len(partition_mounts)} partition(s))"
            )
        if not record.hostname:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}Hostname not found in any vmware-#.log"
        if not record.ips:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}No IPs found in any vmware-#.log"

    elif os_family == "photon":
        # Hostname still comes from the standard Linux reader against the
        # primary (Linux-shaped) partition -- Photon OS follows the normal
        # /etc/hostname convention. The IP lookup searches ALL partitions
        # for the 'messages' log, per direct guidance that it's commonly
        # on a different partition (log_vg_log) than the OS root.
        linux_info = read_linux_info(primary_partition) if primary_partition else {}
        photon_ip_info = read_photon_ip(partition_mounts)

        record.hostname = linux_info.get("hostname")
        record.distro_or_os_info = linux_info.get("distro", "Photon OS / vCenter appliance")
        record.asset_type_id = ASSET_TYPE_LINUX_SERVER

        if photon_ip_info["ip"]:
            record.ips = [photon_ip_info["ip"]]
            record.ip_interface_pairs = [(photon_ip_info["ip"], "DEFAULT_IPV4")]
        else:
            # Fall back to the generic Linux network-config sweep against
            # the primary partition if the messages log didn't have it.
            record.ips = linux_info.get("ips", [])
            record.ip_interface_pairs = linux_info.get("ip_interface_pairs", [])

        if not photon_ip_info["ip"]:
            record.needs_manual_review = True
            record.review_reason = (
                f"DEFAULT_IPV4 not found in 'messages' log "
                f"({photon_ip_info['log_files_searched_count']} candidate file(s) searched across "
                f"{len(partition_mounts)} partition(s))"
                + (" -- fell back to generic Linux network config sweep" if record.ips else "")
            )
        if not record.hostname:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}Hostname not found via any known Linux convention"
        if not record.ips:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}No IPs found via messages log or generic Linux sweep"

    elif os_family == "linux":
        info = read_linux_info(primary_partition)
        record.hostname = info.get("hostname")
        record.ips = info.get("ips", [])
        record.ip_interface_pairs = info.get("ip_interface_pairs", [])
        record.distro_or_os_info = info.get("distro", "")
        record.is_esxi = info.get("is_esxi", False)
        record.asset_type_id = ASSET_TYPE_LINUX_SERVER  # default to server; see note below

        if not record.hostname:
            record.needs_manual_review = True
            record.review_reason = "Hostname not found via any known Linux convention"
        if not record.ips:
            sep = "; " if record.review_reason else ""
            record.needs_manual_review = True
            record.review_reason += f"{sep}No IPs found via any known Linux network config convention"

    else:
        record.needs_manual_review = True
        record.review_reason = (
            "Could not determine OS family across any partition of this image "
            "(no Windows/ dir, no vmware-#.log, no Photon/vCenter markers, "
            "no Linux etc+bin+usr structure on any of "
            f"{len(partition_mounts)} partition(s))"
        )

    return record


def apply_multi_disk_grouping(records: list) -> None:
    """
    Post-pass: for each hostname_dir group, if at least one record resolved
    a hostname, propagate that identity (hostname + IPs + ip_interface_pairs)
    to sibling records in the SAME hostname_dir that found no hostname of
    their own. This implements the direct guidance that a hostname
    directory containing multiple images (e.g. OS drive + data drive)
    represents one host, and a non-OS data drive shouldn't be flagged as a
    separate unknown system when its sibling OS drive already identified
    the host.

    Mutates records in place. Only fills in records that have NO hostname
    at all -- never overwrites a record that found its own (possibly
    different/conflicting) identity, since that could indicate the data
    drive genuinely belongs to a different host than assumed, which is
    exactly the kind of thing that should stay visible rather than be
    silently overwritten.

    If a hostname_dir group has MULTIPLE distinct hostnames resolved across
    its own images (not just "good" + "missing"), that's left alone and
    each record keeps its own finding -- this function only fills gaps, it
    never resolves genuine conflicts.
    """
    from collections import defaultdict

    groups: dict = defaultdict(list)
    for r in records:
        groups[r.source_hostname_dir].append(r)

    for hostname_dir, group in groups.items():
        resolved = [r for r in group if r.hostname]
        unresolved = [r for r in group if not r.hostname]

        if not resolved or not unresolved:
            continue  # nothing to propagate, or nothing needs it

        # If the group has more than one DISTINCT resolved hostname, this
        # is a genuine conflict/ambiguous case -- don't guess which one
        # the unresolved sibling belongs to, leave it flagged instead.
        distinct_hostnames = {r.hostname for r in resolved}
        if len(distinct_hostnames) > 1:
            for r in unresolved:
                sep = "; " if r.review_reason else ""
                r.review_reason += (
                    f"{sep}Could not inherit identity from sibling image in same "
                    f"hostname_dir '{hostname_dir}' -- siblings have CONFLICTING "
                    f"hostnames {sorted(distinct_hostnames)}, manual review required"
                )
            continue

        source = resolved[0]
        for r in unresolved:
            r.hostname = source.hostname
            r.ips = list(source.ips)
            r.ip_interface_pairs = list(source.ip_interface_pairs)
            r.identity_inherited_from = source.partition_mount
            r.needs_manual_review = True  # still worth a human glance, just not "unknown"
            r.review_reason = (
                f"Identity inherited from sibling image '{source.image_path}' "
                f"in the same hostname directory (this partition had no OS/"
                f"hostname info of its own -- likely a non-OS data drive)"
            )


def format_asset_ip(ip_interface_pairs: list) -> str:
    """
    Format (ip, interface) pairs for IRIS's asset_ip field, one pair per
    line as 'IP (interface)', per direct guidance on GUI display.
    """
    if not ip_interface_pairs:
        return ""
    return "\n".join(f"{ip} ({iface})" for ip, iface in ip_interface_pairs)


def discover_partitions(mount_base: Path) -> list[tuple]:
    """
    Read every .mount_state.json under mount_base and return
    (hostname_dir, image_path, partition_mount) tuples for every partition
    listed -- confirmed real structure: state["partitions"] is a list of
    mount point path strings.
    """
    results = []
    state_files = sorted(mount_base.glob("*/*/" + STATE_FILE))

    for sf in state_files:
        try:
            state = json.loads(sf.read_text())
        except (json.JSONDecodeError, OSError) as e:
            print(f"[!] Skipping unreadable state file {sf}: {e}", file=sys.stderr)
            continue

        rel = sf.parent.relative_to(mount_base)
        hostname_dir = rel.parts[0] if rel.parts else "unknown"
        image_path = state.get("image_path", "unknown")

        for partition_mount in state.get("partitions", []):
            results.append((hostname_dir, image_path, partition_mount))

    return results


def main():
    parser = argparse.ArgumentParser(description="Inventory mounted evidence for hostname/IP, multi-OS")
    parser.add_argument("--mount-base", default="/mnt/IOC_SCAN")
    parser.add_argument("--output", default="device_inventory.json")
    args = parser.parse_args()

    mount_base = Path(args.mount_base)
    if not mount_base.exists():
        print(f"[ERROR] Mount base does not exist: {mount_base}", file=sys.stderr)
        sys.exit(1)

    images = discover_images(mount_base)
    if not images:
        print(f"[!] No mounted images found under {mount_base} (no .mount_state.json files with partitions)", file=sys.stderr)
        sys.exit(1)

    records = []
    for image in images:
        print(f"[*] Processing {image['hostname_dir']} :: {image['image_path']} "
              f"({len(image['partition_mounts'])} partition(s))")
        record = process_image(image["hostname_dir"], image["image_path"], image["partition_mounts"])
        records.append(record)
        status = "OK" if not record.needs_manual_review else f"NEEDS REVIEW: {record.review_reason}"
        print(f"    os={record.os_family} hostname={record.hostname} ips={record.ips} [{status}]")

    print("\n[*] Applying multi-disk identity grouping (sibling images in same hostname dir)...")
    apply_multi_disk_grouping(records)
    for r in records:
        if r.identity_inherited_from:
            print(f"    {r.partition_mount} inherited identity from {r.identity_inherited_from}: "
                  f"hostname={r.hostname} ips={r.ips}")

    output_path = Path(args.output)
    output_path.write_text(json.dumps([asdict(r) for r in records], indent=2))

    review_count = sum(1 for r in records if r.needs_manual_review)
    inherited_count = sum(1 for r in records if r.identity_inherited_from)
    print(f"\n[✓] Inventoried {len(records)} image(s). "
          f"{review_count} flagged for manual review, "
          f"{inherited_count} inherited identity from a sibling image.")
    print(f"    Output: {output_path}")


if __name__ == "__main__":
    main()
