#!/usr/bin/env python3
"""
windows_registry_reader.py — Extract hostname and IP configuration from a
mounted Windows image's SYSTEM registry hive, using regipy.

Why SYSTEM hive only (no logs): per design decision, registry survives log
clearing/wiping, which matters for DFIR scenarios where an intruder may have
cleared event logs. Logs are NOT used as a fallback in this version.

Key paths used (well-established, standard Windows registry locations):
  - Hostname:
      SYSTEM\\ControlSet001\\Control\\ComputerName\\ComputerName  -> ComputerName value
    (ControlSet001 is used because CurrentControlSet is a symlink-like
    pointer resolved via SYSTEM\\Select\\Current, which regipy does not
    auto-resolve -- we read \\Select\\Current ourselves to pick the right
    ControlSetNNN explicitly rather than assuming 001.)

  - Network adapters (static + DHCP-assigned IPs):
      SYSTEM\\ControlSet001\\Services\\Tcpip\\Parameters\\Interfaces\\{GUID}
    Each interface subkey may have:
      IPAddress       (multi-string) - static IPs
      DhcpIPAddress   (string)       - last DHCP-leased IP
    A machine can have multiple interfaces; we collect all non-empty,
    non-loopback addresses found across all of them.
"""

from __future__ import annotations

import ipaddress
from pathlib import Path
from typing import Optional

try:
    from regipy.registry import RegistryHive
except ImportError:
    RegistryHive = None  # checked explicitly before use, see read_windows_info()


class WindowsRegistryError(Exception):
    pass


def _get_current_control_set(hive: "RegistryHive") -> str:
    """
    Read SYSTEM\\Select\\Current to find which ControlSetNNN is actually
    active, rather than assuming ControlSet001. Falls back to '001' if the
    Select key is missing/corrupt rather than failing outright -- 001 is
    correct on the large majority of single-boot Windows installs.
    """
    try:
        key = hive.get_key("\\Select")
        for value in key.get_values():
            if value.name == "Current":
                return f"{int(value.value):03d}"
    except Exception:
        pass
    return "001"


def _read_computer_name(hive: "RegistryHive", control_set: str) -> Optional[str]:
    path = f"\\ControlSet{control_set}\\Control\\ComputerName\\ComputerName"
    try:
        key = hive.get_key(path)
        for value in key.get_values():
            if value.name == "ComputerName":
                return str(value.value).strip() or None
    except Exception:
        return None
    return None


def _read_network_ips(hive: "RegistryHive", control_set: str) -> tuple[list[str], list[tuple]]:
    """
    Walk every network interface subkey under Tcpip\\Parameters\\Interfaces
    and collect static + DHCP IPs.

    Returns (ips, ip_interface_pairs) where ips is the flat de-duplicated
    list and ip_interface_pairs is [(ip, None), ...]. The interface slot is
    deliberately left as None rather than the registry's interface GUID
    subkey name (e.g. {a60d1a26-9ba7-4402-...}) -- that GUID isn't a
    meaningful adapter name to show an analyst (unlike ESXi's vmk0/vmk1 or
    Photon's DEFAULT_IPV4 label, which come from human-readable source
    artifacts), and rendering a raw GUID next to every Windows IP just adds
    noise. A friendly adapter name would require cross-referencing a
    separate NetworkCards/Class registry key, which is out of scope here.
    """
    base_path = f"\\ControlSet{control_set}\\Services\\Tcpip\\Parameters\\Interfaces"
    ips: set[str] = set()
    pairs: list[tuple] = []
    seen_pairs: set = set()

    try:
        interfaces_key = hive.get_key(base_path)
    except Exception:
        return [], []

    try:
        subkeys = list(interfaces_key.iter_subkeys())
    except Exception:
        subkeys = []

    for subkey in subkeys:
        try:
            for value in subkey.get_values():
                if value.name in ("IPAddress", "DhcpIPAddress"):
                    candidates = value.value if isinstance(value.value, list) else [value.value]
                    for c in candidates:
                        c = str(c).strip()
                        if not c or c == "0.0.0.0":
                            continue
                        try:
                            addr = ipaddress.ip_address(c)
                            if addr.is_loopback or addr.is_link_local:
                                continue
                            ips.add(c)
                            pair = (c, None)
                            if pair not in seen_pairs:
                                seen_pairs.add(pair)
                                pairs.append(pair)
                        except ValueError:
                            continue  # not a valid IP string, skip silently
        except Exception:
            continue  # one bad subkey shouldn't abort the whole walk

    return sorted(ips), pairs


def read_windows_info(system_hive_path: str) -> dict:
    """
    Open a SYSTEM hive and return:
      {"hostname": str|None, "ips": [str, ...],
       "ip_interface_pairs": [(ip, interface_guid), ...],
       "control_set_used": str}
    Raises WindowsRegistryError if the hive can't be opened at all (corrupt
    file, wrong format, etc) -- caller should catch this and flag the image
    for manual review rather than silently producing an empty result.
    """
    if RegistryHive is None:
        raise WindowsRegistryError(
            "regipy is not installed. Install with: pip install regipy --break-system-packages"
        )

    hive_path = Path(system_hive_path)
    if not hive_path.exists():
        raise WindowsRegistryError(f"SYSTEM hive not found at: {hive_path}")

    try:
        hive = RegistryHive(str(hive_path))
    except Exception as e:
        raise WindowsRegistryError(f"Could not parse SYSTEM hive: {e}")

    control_set = _get_current_control_set(hive)
    hostname = _read_computer_name(hive, control_set)
    ips, ip_interface_pairs = _read_network_ips(hive, control_set)

    return {
        "hostname": hostname,
        "ips": ips,
        "ip_interface_pairs": ip_interface_pairs,
        "control_set_used": control_set,
    }


def find_system_hive(mount_root: str) -> Optional[str]:
    """
    Given a mounted Windows partition root, find the SYSTEM hive at its
    standard location: Windows\\System32\\config\\SYSTEM (case-insensitive
    matching, since NTFS mounted read-only via ntfs-3g is typically
    case-sensitive-looking but the real filesystem is not).
    """
    root = Path(mount_root)
    candidates = [
        root / "Windows" / "System32" / "config" / "SYSTEM",
        root / "WINDOWS" / "System32" / "config" / "SYSTEM",
        root / "windows" / "system32" / "config" / "SYSTEM",
    ]
    for c in candidates:
        if c.exists():
            return str(c)

    # Case-insensitive fallback walk, in case none of the literal casings hit
    windows_dir = None
    for entry in root.iterdir() if root.exists() else []:
        if entry.is_dir() and entry.name.lower() == "windows":
            windows_dir = entry
            break
    if windows_dir:
        config_dir = windows_dir / "System32" / "config"
        if not config_dir.exists():
            for entry in (windows_dir).rglob("config"):
                if entry.is_dir() and entry.parent.name.lower() == "system32":
                    config_dir = entry
                    break
        system_hive = config_dir / "SYSTEM"
        if system_hive.exists():
            return str(system_hive)
        # try case-insensitive filename match within config dir
        if config_dir.exists():
            for entry in config_dir.iterdir():
                if entry.name.upper() == "SYSTEM":
                    return str(entry)

    return None
