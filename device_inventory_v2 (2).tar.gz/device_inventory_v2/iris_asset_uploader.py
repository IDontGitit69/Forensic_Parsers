#!/usr/bin/env python3
"""
iris_asset_uploader.py — Push device_inventory.py's output to DFIR-IRIS as
case Assets.

Designed to run as a SEPARATE step from device_inventory.py, and likely on
a different machine: device_inventory.py runs where the evidence is
actually mounted (e.g. your SIFT workstation), while this script just needs
network access to your IRIS instance -- it doesn't need to run on the same
box, the same lesson learned from the THOR forwarder topology.

Confirmed against a live IRIS v2.4.27 instance via a real curl test:
  POST /case/assets/add?cid=<case_id>
  Required field: asset_name only
  Real asset_type_id values (from assets_type table):
    3=Linux Server, 4=Linux Computer, 9=Windows Computer,
    10=Windows Server, 11=Windows DC

Usage:
  python3 iris_asset_uploader.py \
      --inventory device_inventory.json \
      --iris-host https://192.168.179.X:8443 \
      --api-key <key> \
      --case-id 1
"""

from __future__ import annotations

import argparse
import json
import sys

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def format_asset_ip(ip_interface_pairs: list) -> str:
    """
    Format (ip, interface) pairs for IRIS's asset_ip field: one pair per
    line, as 'IP (interface)', per direct guidance on GUI display.

    ip_interface_pairs comes from JSON, so each pair is a 2-element list
    (JSON has no tuple type), not a Python tuple -- handled generically
    via unpacking either way.
    """
    if not ip_interface_pairs:
        return ""
    lines = []
    for pair in ip_interface_pairs:
        ip, iface = pair[0], pair[1]
        lines.append(f"{ip} ({iface})" if iface else ip)
    return "\n".join(lines)


def build_asset_payload(record: dict) -> dict | None:
    """
    Convert one device_inventory.py record into a /case/assets/add payload.
    Returns None for records with no usable hostname -- we refuse to create
    an asset with no name rather than inventing a placeholder, since an
    unnamed/mis-named asset is worse than a flagged gap (the analyst should
    fix the source record, not have IRIS silently paper over it).

    IMPORTANT: always sets analysis_status_id explicitly. Confirmed live:
    IRIS's case.asset.js DataTable renderer does `data['name']` on the
    analysis_status field with no null check (case.asset.js:504) -- an
    asset created via the API without this field set renders fine
    server-side (the schema allows it as optional) but throws a JS
    TypeError client-side that silently breaks the ENTIRE assets table for
    that case, not just the one row. Every asset created here defaults to
    analysis_status_id=2 ("To be done", confirmed real value from the
    analysis_status table) specifically to avoid ever hitting that bug.
    """
    hostname = record.get("hostname")
    if not hostname:
        return None

    ip_interface_pairs = record.get("ip_interface_pairs", [])
    if ip_interface_pairs:
        asset_ip = format_asset_ip(ip_interface_pairs)
    else:
        # Backward-compat fallback if a record only has the flat ips list
        # (e.g. an older inventory.json from before ip_interface_pairs was
        # added) -- still produce something rather than nothing.
        ips = record.get("ips", [])
        asset_ip = "\n".join(ips) if ips else None

    description_parts = [f"Source image: {record.get('image_path', 'unknown')}"]
    if record.get("distro_or_os_info"):
        description_parts.append(f"OS: {record['distro_or_os_info']}")
    if record.get("is_esxi"):
        description_parts.append("Detected as: VMware ESXi (categorized as Linux - Server, no dedicated ESXi type in IRIS)")
    if record.get("identity_inherited_from"):
        description_parts.append(
            f"⚠ Hostname/IP inherited from sibling image (this disk had no OS info of its own): "
            f"{record['identity_inherited_from']}"
        )
    if record.get("needs_manual_review"):
        description_parts.append(f"⚠ FLAGGED FOR REVIEW: {record.get('review_reason', '')}")

    tags = ["device-inventory"]
    if record.get("is_esxi"):
        tags.append("esxi")
    if record.get("os_family") == "photon":
        tags.append("photon-os")
    if record.get("identity_inherited_from"):
        tags.append("inherited-identity")
    if record.get("needs_manual_review"):
        tags.append("needs-review")

    payload = {
        "asset_name": hostname,
        "asset_description": "\n".join(description_parts),
        "asset_tags": ",".join(tags),
        "analysis_status_id": 2,  # "To be done" -- see docstring above, required to avoid IRIS UI crash
    }
    if asset_ip:
        payload["asset_ip"] = asset_ip
    if record.get("asset_type_id"):
        payload["asset_type_id"] = record["asset_type_id"]

    return payload


def upload_asset(host: str, api_key: str, case_id: int, payload: dict) -> tuple[bool, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post(
            f"{host.rstrip('/')}/case/assets/add",
            params={"cid": case_id},
            headers=headers,
            json=payload,
            verify=False,
            timeout=10,
        )
    except requests.RequestException as e:
        return False, f"Network error: {e}"

    try:
        body = resp.json()
    except Exception:
        return False, f"Non-JSON response (status {resp.status_code}): {resp.text[:300]}"

    if resp.status_code in (200, 201) and body.get("status") == "success":
        asset_id = body.get("data", {}).get("asset_id", "?")
        return True, f"Created asset #{asset_id}: {payload['asset_name']}"

    return False, f"IRIS rejected asset (status {resp.status_code}): {body.get('message', body)}"


def main():
    parser = argparse.ArgumentParser(description="Upload device_inventory.py output to IRIS as Assets")
    parser.add_argument("--inventory", required=True, help="Path to device_inventory.json")
    parser.add_argument("--iris-host", required=True)
    parser.add_argument("--api-key", required=True)
    parser.add_argument("--case-id", type=int, required=True)
    parser.add_argument("--dry-run", action="store_true", help="Print what would be sent, don't actually upload")
    parser.add_argument("--skip-review-flagged", action="store_true",
                        help="Don't upload records flagged needs_manual_review; print them instead for manual handling")
    args = parser.parse_args()

    try:
        records = json.loads(open(args.inventory).read())
    except (OSError, json.JSONDecodeError) as e:
        print(f"[ERROR] Could not read inventory file: {e}", file=sys.stderr)
        sys.exit(1)

    uploaded = 0
    skipped_no_hostname = 0
    skipped_flagged = 0
    failed = 0

    for record in records:
        if args.skip_review_flagged and record.get("needs_manual_review"):
            print(f"[SKIP-FLAGGED] {record.get('source_hostname_dir')} :: {record.get('review_reason')}")
            skipped_flagged += 1
            continue

        payload = build_asset_payload(record)
        if payload is None:
            print(f"[SKIP-NO-HOSTNAME] {record.get('source_hostname_dir')} :: {record.get('partition_mount')}")
            skipped_no_hostname += 1
            continue

        if args.dry_run:
            print(f"[DRY-RUN] Would upload: {json.dumps(payload)}")
            uploaded += 1
            continue

        ok, message = upload_asset(args.iris_host, args.api_key, args.case_id, payload)
        print(("[OK] " if ok else "[FAIL] ") + message)
        if ok:
            uploaded += 1
        else:
            failed += 1

    print(f"\n[Summary] uploaded={uploaded} skipped_no_hostname={skipped_no_hostname} "
          f"skipped_flagged={skipped_flagged} failed={failed}")


if __name__ == "__main__":
    main()
