#!/usr/bin/env python3
"""
photon_reader.py — Extract IP address from a vCenter Server Appliance
(Photon OS) 'messages' log via the DEFAULT_IPV4: <ip> line.

Per direct guidance: this is typically on the 4th partition (log_vg_log
volume group) under a 'vmware' directory, but configuration can vary, so
we search broadly under the mounted partition rather than assume one fixed
path -- same approach as the ESXi vmware.log search.

Hostname for Photon OS / vCenter appliances is still expected to come from
the standard Linux hostname sources (linux_reader.py already covers
/etc/hostname etc, and Photon OS follows that convention) -- this module
covers ONLY the IP address piece, since that's the part that needed a
special-cased artifact per direct guidance.
"""

from __future__ import annotations

import re
from pathlib import Path

DEFAULT_IPV4_RE = re.compile(r"DEFAULT_IPV4:\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)")


def find_messages_logs(mount_roots) -> list[Path]:
    """
    Search broadly under the mounted partition(s) for files named exactly
    'messages' (the standard syslog messages file name), rather than
    assuming a fixed path or a single partition. Per direct guidance, the
    relevant log typically sits on the 4th partition (log_vg_log volume
    group) under a 'vmware' directory, but configuration varies -- and a
    vCenter appliance image can also mount as multiple partitions, so we
    search all of them rather than just the one that triggered detection.

    mount_roots can be a single path string or a list of path strings.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    matches = []
    for mount_root in mount_roots:
        root = Path(mount_root)
        if not root.exists():
            continue
        try:
            for path in root.rglob("messages"):
                if path.is_file():
                    matches.append(path)
            # Also check rotated/compressed-adjacent variants in case the
            # current 'messages' file has already rotated out the relevant line
            for path in root.rglob("messages.*"):
                if path.is_file() and path.suffix not in (".gz", ".bz2", ".xz"):
                    matches.append(path)
        except (PermissionError, OSError):
            continue

    return matches


def read_photon_ip(mount_roots) -> dict:
    """
    Search for 'messages' log file(s) across the given partition mount(s)
    and extract DEFAULT_IPV4 value(s).
    Returns {"ip": str|None, "log_files_found": [...], "log_files_searched_count": int}

    mount_roots can be a single path string or a list of path strings.
    """
    result = {"ip": None, "log_files_found": [], "log_files_searched_count": 0}

    messages_files = find_messages_logs(mount_roots)
    result["log_files_searched_count"] = len(messages_files)

    found_ips = []
    for log_file in messages_files:
        try:
            content = log_file.read_text(errors="ignore")
        except OSError:
            continue
        matches = DEFAULT_IPV4_RE.findall(content)
        if matches:
            result["log_files_found"].append(str(log_file))
            found_ips.extend(matches)

    if found_ips:
        # Most recently-written occurrence is likely last in the file for
        # an append-only log; take the last match found across all files
        # as the most current value rather than majority vote (DHCP lease
        # could legitimately change over the log's lifetime, and we want
        # the latest, not the most repeated).
        result["ip"] = found_ips[-1]

    return result


def is_photon_partition(mount_roots) -> bool:
    """
    Cheap check for whether a partition (or set of partitions) looks like
    it could be a Photon OS / vCenter appliance, used by the orchestrator
    to decide whether to try this reader at all. Looks for the standard
    Photon OS /etc/os-release PRETTY_NAME or VMware-specific marker paths
    on ANY of the given partitions, since a 'messages' file alone isn't
    distinctive (every Linux box has one) and the appliance may mount as
    multiple partitions.

    mount_roots can be a single path string or a list of path strings.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    for mount_root in mount_roots:
        root = Path(mount_root)
        os_release = root / "etc" / "os-release"
        if os_release.exists():
            try:
                content = os_release.read_text(errors="ignore")
                if "photon" in content.lower() or "vmware" in content.lower():
                    return True
            except OSError:
                pass

        vcsa_markers = [
            root / "etc" / "vmware-vpx",
            root / "usr" / "lib" / "vmware-vpx",
        ]
        if any(m.exists() for m in vcsa_markers):
            return True

    return False
