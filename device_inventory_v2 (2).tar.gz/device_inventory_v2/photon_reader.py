#!/usr/bin/env python3
"""
photon_reader.py — Extract IP address from a vCenter Server Appliance
(Photon OS) 'messages' log via the DEFAULT_IPV4: <ip> line.

Per direct guidance: this is typically on the 4th partition (log_vg_log
volume group) under a 'vmware' directory, but configuration can vary, so
we search broadly under the mounted partition rather than assume one fixed
path -- same approach as the ESXi vmware.log search.

Hostname for Photon OS / vCenter appliances is still expected to come from
the standard Linux hostname sources (linux_reader.py already covers
/etc/hostname etc, and Photon OS follows that convention) -- this module
covers ONLY the IP address piece, since that's the part that needed a
special-cased artifact per direct guidance.
"""

from __future__ import annotations

import re
from pathlib import Path

DEFAULT_IPV4_RE = re.compile(r"DEFAULT_IPV4:\s*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)")


def find_messages_logs(mount_roots, verbose: bool = False) -> list[Path]:
    """
    Search broadly under the mounted partition(s) for files named exactly
    'messages' (the standard syslog messages file name), rather than
    assuming a fixed path or a single partition. Per direct guidance, the
    relevant log is commonly on an LVM logical volume named something like
    log_vg-log, but this isn't guaranteed across every vCenter deployment,
    so this searches every given partition path fully (rglob has no depth
    limit) rather than assuming a specific volume name or position.

    mount_roots can be a single path string or a list of path strings.
    verbose=True prints how many files were found per partition, so a
    "found nothing" result can be diagnosed against which partitions were
    actually searched and whether any of them errored out partway.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    matches = []
    for mount_root in mount_roots:
        root = Path(mount_root)
        if not root.exists():
            if verbose:
                print(f"    [messages-search] {root} does not exist, skipping")
            continue

        found_here = 0
        try:
            for path in root.rglob("messages"):
                if path.is_file():
                    matches.append(path)
                    found_here += 1
            # Also check rotated/compressed-adjacent variants in case the
            # current 'messages' file has already rotated out the relevant line
            for path in root.rglob("messages.*"):
                if path.is_file() and path.suffix not in (".gz", ".bz2", ".xz"):
                    matches.append(path)
                    found_here += 1
        except (PermissionError, OSError) as e:
            if verbose:
                print(f"    [messages-search] error walking {root}: {e} (partial results may be missing)")
            continue

        if verbose:
            print(f"    [messages-search] {root}: found {found_here} candidate file(s)")

    return matches


def read_photon_ip(mount_roots, verbose: bool = False) -> dict:
    """
    Search for 'messages' log file(s) across the given partition mount(s)
    and extract DEFAULT_IPV4 value(s).
    Returns {"ip": str|None, "log_files_found": [...], "log_files_searched_count": int}

    mount_roots can be a single path string or a list of path strings.
    """
    result = {"ip": None, "log_files_found": [], "log_files_searched_count": 0}

    messages_files = find_messages_logs(mount_roots, verbose=verbose)
    result["log_files_searched_count"] = len(messages_files)

    found_ips = []
    for log_file in messages_files:
        try:
            content = log_file.read_text(errors="ignore")
        except OSError:
            continue
        matches = DEFAULT_IPV4_RE.findall(content)
        if matches:
            result["log_files_found"].append(str(log_file))
            found_ips.extend(matches)
        elif verbose:
            print(f"    [messages-search] {log_file}: no DEFAULT_IPV4 line found in this file")

    if found_ips:
        # Most recently-written occurrence is likely last in the file for
        # an append-only log; take the last match found across all files
        # as the most current value rather than majority vote (DHCP lease
        # could legitimately change over the log's lifetime, and we want
        # the latest, not the most repeated).
        result["ip"] = found_ips[-1]

    return result


def is_photon_partition(mount_roots, verbose: bool = False) -> bool:
    """
    Check for whether a partition (or set of partitions) looks like it
    could be a Photon OS / vCenter appliance.

    Broadened from the original version, which only checked
    <partition_root>/etc/os-release and <partition_root>/etc/vmware-vpx at
    the EXACT top level of each given path -- too narrow if the real OS
    root sits one level deeper than expected (e.g. nested under an LVM
    logical volume mount point that doesn't line up with what we assumed,
    or a partition numbering/order that differs from a typical vCenter
    appliance layout).

    Now checks, on every given partition root AND up to 2 levels of
    subdirectories under it (cheap since we're only checking a few fixed
    relative paths per directory, not a full recursive walk):
      - etc/os-release containing "photon" or "vmware"
      - etc/vmware-vpx or usr/lib/vmware-vpx (VCSA-specific)
      - etc/vmware-release (in case an installed component shares this
        marker with ESXi's convention)
      - presence of a directory literally named 'vmware' anywhere in the
        first 2 levels (cheap heuristic, not authoritative alone, but
        useful as a directory-naming hint per the "log_vg-log" style
        volume-group naming you're seeing in practice)

    verbose=True prints exactly what was checked and what was found on
    each partition, for diagnosing exactly why a real vCenter image's
    layout isn't matching what we expect, rather than guessing again.

    mount_roots can be a single path string or a list of path strings.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    def candidate_roots(partition_root: Path):
        """Yield the partition root itself plus up to 2 levels of subdirs."""
        yield partition_root
        try:
            for child in partition_root.iterdir():
                if child.is_dir():
                    yield child
                    try:
                        for grandchild in child.iterdir():
                            if grandchild.is_dir():
                                yield grandchild
                    except (PermissionError, OSError):
                        continue
        except (PermissionError, OSError):
            return

    for mount_root in mount_roots:
        partition_root = Path(mount_root)
        if not partition_root.exists():
            if verbose:
                print(f"    [photon-check] {partition_root} does not exist, skipping")
            continue

        for candidate in candidate_roots(partition_root):
            os_release = candidate / "etc" / "os-release"
            if os_release.exists():
                try:
                    content = os_release.read_text(errors="ignore")
                    if verbose:
                        print(f"    [photon-check] found {os_release}, content snippet: {content[:120]!r}")
                    if "photon" in content.lower() or "vmware" in content.lower():
                        if verbose:
                            print(f"    [photon-check] MATCH via os-release at {os_release}")
                        return True
                except OSError as e:
                    if verbose:
                        print(f"    [photon-check] could not read {os_release}: {e}")

            markers = [
                candidate / "etc" / "vmware-vpx",
                candidate / "usr" / "lib" / "vmware-vpx",
                candidate / "etc" / "vmware-release",
            ]
            for marker in markers:
                if marker.exists():
                    if verbose:
                        print(f"    [photon-check] MATCH via marker path {marker}")
                    return True

            vmware_dir = candidate / "vmware"
            if vmware_dir.is_dir():
                if verbose:
                    print(f"    [photon-check] MATCH via 'vmware' directory at {vmware_dir} "
                          f"(heuristic match, not a definitive OS marker)")
                return True

        if verbose:
            print(f"    [photon-check] no match found under {partition_root} "
                  f"(checked root + up to 2 levels of subdirectories)")

    return False
