# Device Inventory → IRIS Asset Pipeline

Two-stage pipeline: collect hostname/IP from mounted evidence (any mix of
Windows/Linux/ESXi/Photon OS), then push results to DFIR-IRIS as case
Assets.

## Why two separate scripts

`device_inventory.py` runs **where the evidence is mounted** (your SIFT
workstation). `iris_asset_uploader.py` only needs network access to IRIS —
it can run on the same box or a different one. Same lesson learned from the
THOR forwarder: don't assume the evidence host and the IRIS host are the
same machine.

## Pipeline

```
mount_evidence.py (already have this)
        │
        ▼
.mount_state.json files under /mnt/IOC_SCAN/<host>/<image>/
        │
        ▼
device_inventory.py  →  device_inventory.json
   - reads mount_state.json directly (confirmed real structure)
   - detects OS family per partition, priority order:
       Windows -> ESXi -> Photon/vCenter -> generic Linux
   - Windows         -> windows_registry_reader.py (regipy, SYSTEM hive only)
   - ESXi            -> esxi_reader.py (vmware-#.log: Hostname=, IP=<ip> (<iface>))
   - Photon/vCenter  -> photon_reader.py (messages log: DEFAULT_IPV4) + linux_reader
                        for hostname (Photon follows standard /etc/hostname)
   - generic Linux   -> linux_reader.py (multi-distro)
   - multi-disk grouping post-pass: sibling images in the same hostname_dir
     inherit a resolved identity if they have none of their own (e.g. a
     non-OS data drive sitting alongside the OS drive)
        │
        ▼
iris_asset_uploader.py  →  POST /case/assets/add?cid=<case_id>
   - one real IRIS Asset per identified host
   - asset_ip formatted as one "IP (interface)" pair per line
```

## Install

```bash
pip install regipy requests --break-system-packages
```

(`regipy` is only needed on whichever machine runs `device_inventory.py`
against Windows images. `iris_asset_uploader.py` only needs `requests`.)

## Run

```bash
# On the evidence host (e.g. SIFT workstation):
python3 device_inventory.py --mount-base /mnt/IOC_SCAN --output inventory.json

# Review the output, especially anything with needs_manual_review: true
cat inventory.json

# Then, from anywhere with network access to IRIS:
python3 iris_asset_uploader.py \
    --inventory inventory.json \
    --iris-host https://<iris-host-ip>:8443 \
    --api-key <your-api-key> \
    --case-id <case-id> \
    --dry-run   # remove once the dry-run output looks right
```

## What's confirmed vs. what to verify on your own images

**Confirmed by direct testing in this conversation:**
- `mount_state.json` real structure (image_path, partitions list, etc.)
- IRIS `POST /case/assets/add?cid=X` — real endpoint, real required fields,
  tested live against a running v2.4.27 instance (created real assets)
- Real `assets_type` IDs: 3=Linux Server, 4=Linux Computer, 9=Windows
  Computer, 10=Windows Server, 11=Windows DC
- `analysis_status_id` must always be set explicitly (see "IRIS frontend
  bug" section below) — confirmed via live testing, not theoretical
- Windows registry reader tested against a real (intact) SYSTEM hive via
  `hivex` — correctly extracted hostname (`NIHEXB5`) and per-interface IPs
- Linux reader logic tested against synthetic Ubuntu/netplan, CentOS/legacy
  ifcfg structures — all correctly identified
- ESXi reader (`esxi_reader.py`) tested against a synthetic vmware-#.log
  fixture matching the real Hostname=/IP=<ip> (<iface>) format — correctly
  extracted hostname and both interface IPs
- Photon/vCenter reader (`photon_reader.py`) tested against a synthetic
  messages-log fixture with DEFAULT_IPV4 — correctly extracted the IP
- Multi-disk identity grouping tested against three scenarios directly:
  clean inheritance (sibling with no OS info inherits from resolved
  sibling), no-op (standalone host untouched), and genuine conflict
  (two siblings with DIFFERENT resolved hostnames — correctly refuses to
  guess which one a third unresolved sibling belongs to, flags for
  manual review instead)
- Unrecognized partition correctly flagged `needs_manual_review` rather
  than silently producing a wrong/empty asset
- Multi-line `asset_ip` formatting (`IP (interface)` per line) verified in
  dry-run output

**NOT tested against real ESXi/Photon evidence** — `esxi_reader.py` and
`photon_reader.py` were built and tested against synthetic log fixtures
matching the documented/provided line formats, not real vmware-#.log or
messages files pulled from an actual ESXi host or vCenter appliance image.
Run these against your real evidence and check the `ip_interface_pairs`
output looks sane before trusting it on a full case.

## Known limitations (by design, not oversights)

- **IP extraction from generic Linux config files is a regex sweep, not a
  real parser** for each format (YAML/INI/etc). It will return gateway and
  DNS addresses mixed in with the host's actual IP, and reports interface
  as `"unknown"` for these since the sweep can't reliably attribute an IP
  to a specific adapter — see the docstring on `_extract_ips_from_text()`
  in `linux_reader.py`. ESXi and Photon readers don't have this limitation
  since their source artifacts explicitly state the interface name/label.
- **Windows asset subtype (Computer/Server/DC) is guessed from hostname
  text** (`"DC"`/`"SRV"` substrings). Treat as a starting point to correct
  in the IRIS UI, not a confident classification.
- **ESXi/vCenter get no dedicated IRIS asset type** (none exists in this
  IRIS install) — created as "Linux - Server" with `is_esxi`/`photon-os`
  noted in description/tags, per explicit choice.
- **No create-or-update logic** — re-running the uploader against the same
  case will likely hit IRIS's unique-asset-name-per-case constraint and
  fail on duplicates rather than updating them.
- **Multi-disk grouping only fills gaps, never resolves conflicts.** If two
  images in the same hostname directory each independently resolve a
  DIFFERENT hostname, neither is touched and any other unresolved sibling
  in that group is flagged for manual review rather than guessed at.

## Corrupted SYSTEM hive recovery — tabled as a known edge case

A damaged/corrupted SYSTEM hive that fails to parse with `regipy` was also
tested against `hivex` (Red Hat's libguestfs hive library, generally more
damage-tolerant) using the same source file confirmed via hash match to a
direct mount copy (ruling out an export-artifact explanation). `hivex`
also failed to open it (`Operation not supported`). A from-scratch raw
byte-scraping approach was also attempted and found unreliable: registry
value names and their corresponding value data live in separate, linked
cells rather than adjacent bytes, so scraping without following that
structural link cannot reliably recover the value even when the name
anchor itself is found.

**Current status: tabled as a known edge case**, by deliberate choice, to
keep this a focused, real-world problem rather than an open-ended one. A
hive in this state most likely has genuine structural damage beyond what
any current approach in this project can recover. Partitions whose only
findable identity source is a hive in this state will be flagged
`needs_manual_review` with the specific parse error recorded, rather than
silently producing empty/wrong results. Revisit this only if it turns out
to affect more than a rare one-off image — diagnostic scripts used during
investigation (`test_raw_hive_scrape.py`, `diagnose_hive_encoding.py`,
`test_hivex.py` in this delivery) are kept for reference if that happens.

## Recent fixes (post-initial-delivery)

**1. Windows interface GUID removed from asset_ip display.** The Windows
registry reader previously paired each IP with its raw interface GUID
subkey name (e.g. `{a60d1a26-9ba7-...}`), which rendered as noise in IRIS.
Windows IPs now report with `interface=None`, which `iris_asset_uploader.py`
renders as a bare IP with no parenthetical — matching how it looked before
interface tracking was added, while ESXi (`vmk0`, `vmk1`) and Photon
(`DEFAULT_IPV4`) keep their meaningful interface labels since those come
from human-readable source artifacts.

**2. ESXi/Photon detection no longer gated behind a Linux-shaped check,
and now searches ALL partitions of an image, not just one.** The original
design only attempted ESXi/Photon detection on a partition that already
had a conventional top-level `etc`+`bin`/`usr`/`var` layout — but ESXi's
actual on-disk structure doesn't necessarily look like that, and per
direct guidance, a single ESXi image commonly mounts as multiple
partitions (boot bank, store, scratch, etc) where the relevant
`vmware-#.log` may sit on a different partition than whichever one looks
"Linux-shaped." This caused real ESXi/vCenter images to silently fall
through to `unknown` with `is_esxi: false`.

Fixed by restructuring the orchestrator around **images** instead of
individual partitions: `discover_images()` groups all partitions
belonging to one `.mount_state.json` entry together, `detect_os_family()`
now takes the full list and checks ESXi/Photon markers unconditionally
across every partition (no Linux-shaped gate), and `esxi_reader.py` /
`photon_reader.py`'s search functions now accept either a single path or a
list of paths, searching all of them. Verified against a fixture
specifically reproducing the bug: a two-partition ESXi image where
*neither* partition has a conventional Unix layout, and the log file
lives on a different partition than the VMware marker file — now
correctly detected and inventoried.

**3. New last-resort "messages-file fallback" tier when NO standard OS
markers are found anywhere.** Real vCenter appliances were encountered
where none of the standard Photon markers (`/etc/os-release` mentioning
photon/vmware, vcsa marker paths) existed on any partition — the
"traditional places" genuinely aren't always there. Rather than continue
trying to definitively classify the OS, `detect_os_family()` now has a
5th tier: if Windows/ESXi/Photon/generic-Linux all fail to match on every
partition of the image, it searches all partitions one more time for any
`messages` file containing `DEFAULT_IPV4` (reusing the same search
`photon_reader.py` already does — no new search logic, just relaxing
when it's allowed to run).

If that fallback finds an IP, the record is tagged `os_family:
"unknown_with_messages_ip"` (deliberately NOT `"photon"` — we are not
confident this is Photon OS, only that this artifact produced an IP),
`hostname` falls back to the **hostname directory name** (no other
hostname detection is attempted), `asset_type_id` is left `null`, and the
record is always flagged `needs_manual_review` with an explicit
"VERIFY this hostname/IP manually" note. If even that fallback finds
nothing, the record falls through to plain `"unknown"` exactly as before.

Verified against two fixtures: one with a `messages`/`DEFAULT_IPV4` file
buried under an unrelated-looking path with zero other markers anywhere
(correctly produces `unknown_with_messages_ip` with the right IP and
directory-name hostname), and one with genuinely nothing findable at all
(correctly falls through to plain `unknown`). Confirmed no regression
against all prior ESXi/Photon/multi-disk test fixtures.

**4. Photon hostname lookup now searches ALL partitions, not just the
"primary" one.** A real vCenter appliance was found where the OS family
correctly resolved to `photon` (via the broadened marker search), the IP
was correctly found via the `messages` log, but `hostname` came back
`None`. Root cause: the Photon branch was calling `read_linux_info()`
against only the single "primary" partition that triggered Photon marker
detection — but that partition isn't guaranteed to be the same one
carrying `/etc/hostname`. Added `read_hostname_multi()` in
`linux_reader.py`, which tries every partition belonging to the image and
returns the first hit, the same multi-partition treatment the IP lookup
already had. The Photon branch in `device_inventory.py` now uses this
instead of a single-partition lookup.

**5. Fixed a real data-loss bug in multi-disk identity inheritance.**
`apply_multi_disk_grouping()` was unconditionally overwriting a record's
`ips`/`ip_interface_pairs` with the sibling's values whenever inheriting
a hostname — including for records that already had their OWN correctly
-found IP and were only missing a hostname (exactly the scenario in fix
#4 above, before that was fixed: a Photon partition with a real IP from
the messages-log search, no hostname). This silently replaced a correct,
independently-found IP with a sibling's IP, which is almost certainly
wrong for a multi-NIC/multi-volume host where different partitions
correspond to different interfaces. Fixed: IPs are now only inherited
if the record has NO IPs of its own; hostname is still always inherited
unconditionally when missing. Verified directly: a record with its own
IP and a sibling with a hostname now correctly inherits ONLY the
hostname, keeping its own IP untouched. Also confirmed this fix resolves
the original symptom where such records failed to upload to IRIS at all
(`iris_asset_uploader.py` skips any record with no hostname — once
hostname inheritance/lookup is fixed, the upload proceeds normally).

**6. Added a universal directory-name fallback, applied ONCE per hostname
directory, after all detection and inheritance.** Per direct clarification
on the real mount layout: `IOC_SCAN/<hostname_dir>/<image>/...`, where a
single hostname directory commonly contains several SEPARATE images (not
just multiple partitions of one image — e.g. a vCenter host's ~11 disks
each being their own `.mount_state.json` entry), and the directory name
itself is "many times" already the real hostname.

Previously, the directory-name fallback only fired inside the
`unknown_with_messages_ip` branch, on a per-image basis — there was no
universal "if NOTHING resolved anywhere in this whole hostname directory,
use the directory name for everything in it" rule, which is what was
actually being asked for.

Added `apply_directory_name_fallback()`, run after
`apply_multi_disk_grouping()`: for each hostname_dir group, if EVERY
record in that group (after detection AND inheritance) still has no
hostname at all, the directory name is assigned once and shared across
every record in the group. If even one record in the group already has a
hostname (via direct detection or via inheritance from a sibling), this
fallback does not run at all for that group — it is strictly a last
resort, never a substitute for a real finding.

Verified against three scenarios: (a) multiple separate images under one
hostname directory where NONE resolve anything — all now correctly share
the directory name; (b) one image resolves correctly while 3 siblings
don't — siblings correctly inherit the REAL hostname via the existing
mechanism, the directory-name fallback does not override it; (c) full
regression sweep across every prior test fixture confirms no record is
left with `hostname: null` in final output any longer — every previously
"unknown" record now has either a real detected hostname, an inherited
one, or the directory-name fallback.

