#!/usr/bin/env python3
"""
esxi_reader.py — Extract hostname and IP+interface pairs from ESXi
vmware-#.log files.

Per direct guidance: ESXi's Hostname and IP/interface info is reliably
found in vmware-#.log (there can be multiple), but the file's location on
a given datastore/partition isn't guaranteed, so we search broadly under
the mounted partition rather than assume one fixed path.

Log line formats this looks for (based on the provided vmware_log_sweep.sh
reference, which we ported the same regex logic from):
    Hostname=<value>
    IP=<ip> (<interface>)

A single ESXi host can have multiple vmware-#.log files (one per VM/
process context on the host) and multiple IP/interface lines across them.
We aggregate everything found across all matching files for the partition,
since the goal is a complete picture of the host's network configuration,
not picking "the one true" log file.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

HOSTNAME_RE = re.compile(r"Hostname=(\S+)")
IP_IFACE_RE = re.compile(r"IP=([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\s*\(([^)]+)\)")


@dataclass
class EsxiNetworkInfo:
    hostname: str | None = None
    ip_interface_pairs: list = field(default_factory=list)  # [(ip, iface), ...]
    log_files_found: list = field(default_factory=list)
    log_files_searched_count: int = 0


def find_vmware_logs(mount_roots) -> list[Path]:
    """
    Search broadly under the mounted partition(s) for vmware-#.log /
    vmware.log files, rather than assuming a fixed path or a single
    partition -- per direct guidance, an ESXi image commonly mounts as
    multiple partitions (boot bank, store, scratch, etc), and the relevant
    log files may live on any one of them, not necessarily the partition
    that triggered ESXi detection in the first place.

    mount_roots can be a single path string (kept for backward
    compatibility with direct calls) or a list of path strings.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    matches = []
    for mount_root in mount_roots:
        root = Path(mount_root)
        if not root.exists():
            continue
        try:
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                name_lower = path.name.lower()
                if name_lower.startswith("vmware") and name_lower.endswith(".log"):
                    matches.append(path)
        except (PermissionError, OSError):
            continue

    return matches


def parse_vmware_log(path: Path) -> tuple[list, list]:
    """
    Parse one vmware-#.log file for Hostname= and IP=<ip> (<iface>) lines.
    Returns (hostnames_found, ip_interface_pairs_found) for this file alone.
    """
    hostnames = []
    ip_pairs = []
    try:
        content = path.read_text(errors="ignore")
    except OSError:
        return hostnames, ip_pairs

    for match in HOSTNAME_RE.finditer(content):
        hostnames.append(match.group(1).strip())

    for match in IP_IFACE_RE.finditer(content):
        ip_pairs.append((match.group(1).strip(), match.group(2).strip()))

    return hostnames, ip_pairs


def read_esxi_info(mount_roots) -> EsxiNetworkInfo:
    """
    Search the mounted partition(s) for all vmware-#.log files, parse each,
    and aggregate. Hostname is chosen by majority vote across all files
    (most common value wins) since multiple log files may report slightly
    different/stale hostnames, and IP/interface pairs are deduplicated but
    otherwise all kept -- a host can legitimately have many interfaces.

    mount_roots can be a single path string or a list of path strings (all
    partitions belonging to one image) -- see find_vmware_logs.
    """
    info = EsxiNetworkInfo()
    log_files = find_vmware_logs(mount_roots)
    info.log_files_searched_count = len(log_files)

    all_hostnames: list[str] = []
    all_ip_pairs: list[tuple] = []

    for log_file in log_files:
        hostnames, ip_pairs = parse_vmware_log(log_file)
        if hostnames or ip_pairs:
            info.log_files_found.append(str(log_file))
        all_hostnames.extend(hostnames)
        all_ip_pairs.extend(ip_pairs)

    if all_hostnames:
        # Majority vote: most frequently reported hostname across all logs
        info.hostname = Counter(all_hostnames).most_common(1)[0][0]

    # Deduplicate (ip, iface) pairs while preserving first-seen order
    seen = set()
    deduped_pairs = []
    for pair in all_ip_pairs:
        if pair not in seen:
            seen.add(pair)
            deduped_pairs.append(pair)
    info.ip_interface_pairs = deduped_pairs

    return info


def is_esxi_partition(mount_roots) -> bool:
    """
    Quick check for whether a partition (or set of partitions) looks like
    an ESXi datastore/boot partition, used by the orchestrator to decide
    whether to even try this reader. Presence of any vmware-#.log file is
    itself a strong signal, so this just reuses find_vmware_logs with an
    early-exit for speed.

    mount_roots can be a single path string or a list of path strings.
    """
    if isinstance(mount_roots, (str, Path)):
        mount_roots = [mount_roots]

    for mount_root in mount_roots:
        root = Path(mount_root)
        if not root.exists():
            continue
        try:
            for path in root.rglob("*"):
                if path.is_file():
                    name_lower = path.name.lower()
                    if name_lower.startswith("vmware") and name_lower.endswith(".log"):
                        return True
        except (PermissionError, OSError):
            continue
    return False
