# IrisYaraExport

A DFIR-IRIS **processor module** that keeps a YARA rule bundle automatically
in sync with a case's IOCs. No manual export, no polling script — IRIS calls
this module the moment an analyst creates, edits, or deletes an IOC.

## What it does

```
Analyst adds/edits/deletes an IOC in IRIS
              │
              ▼
   IRIS commits to DB, fires hook
   (on_postload_ioc_create/update/delete)
              │
              ▼
      IrisYaraExportModule.hooks_handler()
              │
              ▼
  <yara_output_dir>/<case_name>.yar updated
  (rule added / replaced / removed)
              │
              ▼
   Your scanner (e.g. THOR Lite) reads from
   that directory on its next scheduled run
```

Each case gets its own bundle file, named from the case name (sanitized),
e.g. `Engagement_69.yar`. Within the file, each IOC's rule is tagged with a
hidden `// IOC_ID:<n>` comment so the module can find and replace or remove
just that one rule without touching the rest of the file — your bundle isn't
clobbered and regenerated from scratch on every single IOC edit.

## IOC type → YARA rule mapping

Identical detection logic to the original standalone script: IPv4/IPv6
(ASCII + wide + raw byte pattern), domains, URLs, MD5/SHA1/SHA256 hashes,
and a generic string fallback for anything else (filenames, mutexes, etc).

## Install

This follows the standard DIM build/install flow:

```bash
cd iris_yara_module
python3 setup.py sdist bdist_wheel
# copy the produced .whl into the IRIS docker container's dependencies dir,
# then install it and restart, as described in:
# https://docs.dfir-iris.org/operations/modules/mod_management/
```

For local development against a docker IRIS instance, use the
`buildnpush2iris.sh` script referenced in the
[processor module quick-start](https://docs.dfir-iris.org/development/modules/quick_start/processor/)
docs — it builds, copies into the running containers, and restarts them.

## Configuration (set in IRIS: Advanced > Modules > IrisYaraExport)

| Parameter | Description | Default |
|---|---|---|
| YARA output directory | Where per-case `.yar` files are written. Point this at your scanner's custom-rules directory (e.g. THOR Lite's `custom-signatures` folder), or at a directory that's synced/mounted there. | `/iris_data/yara_export` |
| Update bundle on IOC create | Add a rule when a new IOC is created | `True` |
| Update bundle on IOC update | Replace the rule when an IOC is edited | `True` |
| Update bundle on IOC delete | Remove the rule when an IOC is deleted | `True` |

**The output directory must be writable by the IRIS worker process** (the
processor that actually executes `hooks_handler` — see the "Overview"
section of the modules documentation: modules can live in the worker, the
web app, or both, depending on type).

## Important limitations to know before relying on this

- **This module never touches your mounted evidence or runs THOR.** It only
  maintains a `.yar` text file. Your THOR Lite invocation, scheduling, and
  evidence mounting remain entirely outside IRIS — this module replaces only
  the "pull IOCs from IRIS and convert to YARA" step of your pipeline.
- **The output directory needs to be reachable from wherever IRIS's worker
  runs.** If IRIS runs in Docker and your scanner runs on the bare host (or
  vice versa), `yara_output_dir` needs to be a path that's actually shared
  between them — a bind-mounted volume, a network share, or similar. This
  module has no awareness of that infrastructure; it just writes to a path.
- **Case resolution is now grounded in a confirmed schema, not guessed.**
  Verified directly against a live IRIS v2.4.27 instance: the `Ioc` model has
  no `case`/`case_id` attribute at all — an IOC row is global and linked to
  one or more cases through a separate `ioc_link` table (`ioc_link_id`,
  `ioc_id`, `case_id`). `_resolve_cases()` queries that table directly via
  raw SQL (`SELECT c.case_id, c.name FROM ioc_link il JOIN cases c ON
  c.case_id = il.case_id WHERE il.ioc_id = :ioc_id`). The case name column
  is `cases.name`, not `case_name` (that field name only appears in IRIS's
  Jinja report-template context, not on the raw SQLAlchemy model). The IOC
  type's readable name is at `ioc.ioc_type.type_name` (e.g. `"ip-src"`),
  not a direct `ioc.type_name`.
- **One IOC can belong to multiple cases.** Because of the `ioc_link`
  join table, create/update writes the rule into *every* linked case's
  bundle, not just one. If your IRIS setup never shares IOCs across cases,
  this just means each bundle ends up correct anyway, but it's worth
  knowing the rule isn't scoped to "the case where it was created."
- **Deletes can't query `ioc_link` for case linkage** — by the time
  `on_postload_ioc_delete` fires, the IOC and its `ioc_link` rows are
  already gone. `_handle_delete` instead scans every `.yar` file under
  `yara_output_dir` and strips the matching `// IOC_ID:<n>` block from
  whichever ones contain it. This is correct regardless of how many cases
  the IOC was linked to, just a different mechanism than create/update.
- **If you're on a different IRIS version than 2.4.27**, the schema above
  might not match exactly. Re-run the verification queries below against
  your own instance before trusting this module's output.

## Verifying against your IRIS version

Run these inside your `worker` container to confirm the schema this module
relies on still holds:

```bash
docker compose exec worker python3 -c "
from app import app, db
from app.models import Ioc
with app.app_context():
    ioc = Ioc.query.first()
    print('Ioc attrs:', [a for a in dir(ioc) if not a.startswith('_')])
    print('ioc_type.type_name:', ioc.ioc_type.type_name)
    inspector = db.inspect(db.engine)
    print('ioc_link columns:', [c['name'] for c in inspector.get_columns('ioc_link')])
    print('cases columns:', [c['name'] for c in inspector.get_columns('cases')])
"
```

If `ioc_link` doesn't exist or its columns differ, update the SQL query in
`_resolve_cases()` (`IrisYaraExportModule.py`) to match before relying on this
in production.
- **No retroactive backfill.** This module only reacts to hooks going
  forward. IOCs that existed before the module was installed won't appear
  in a bundle until they're edited (which re-fires `on_postload_ioc_update`).
  To backfill an existing case's IOCs into a bundle once, you can still run
  the original standalone `iris_ioc_to_yara.py` script against that case —
  the two approaches aren't mutually exclusive.

## Testing locally

1. Spin up an IRIS docker instance (see the [Quick Start](https://docs.dfir-iris.org/getting_started/) guide).
2. Build and install this module per the steps above.
3. Go to **Advanced > Modules**, find `IrisYaraExport`, configure the output
   directory to something on a volume you can inspect from the host, and
   enable it.
4. Create a test case, add an IOC (e.g. a fake IP `185.199.110.153`), and
   check the configured output directory for `<case_name>.yar`.
5. Edit the IOC's description, confirm the rule's `description` meta field
   updates in place rather than duplicating.
6. Delete the IOC, confirm its rule block disappears from the file.
