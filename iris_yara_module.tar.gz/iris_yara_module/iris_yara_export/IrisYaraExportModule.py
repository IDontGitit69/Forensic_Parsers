#!/usr/bin/env python3
"""
IrisYaraExportModule.py — Main interface class.

Registers for the three IOC lifecycle hooks (create/update/delete) and keeps
a per-case .yar bundle file in sync as analysts work in IRIS. This replaces
the "analyst inputs IOC -> external script polls API -> converts to YARA"
flow with a push: IRIS calls this module the moment an IOC is committed.
"""

from iris_interface.IrisModuleInterface import IrisModuleInterface
from iris_interface import IrisInterfaceStatus

from app import db
from sqlalchemy import text

from . import IrisYaraExportConfig as interface_conf
from .module_helper import bundle_writer


class IrisYaraExportModule(IrisModuleInterface):
    # ── Module configuration (see IrisYaraExportConfig.py) ──────────────────
    _module_name = interface_conf.module_name
    _module_description = interface_conf.module_description
    _interface_version = interface_conf.interface_version
    _module_version = interface_conf.module_version
    _pipeline_support = interface_conf.pipeline_support
    _pipeline_info = interface_conf.pipeline_info
    _module_configuration = interface_conf.module_configuration
    _module_type = interface_conf.module_type

    def register_hooks(self, module_id: int):
        """
        Called by IRIS when the module is installed/enabled, and again any
        time an admin changes its configuration. We subscribe to all three
        IOC lifecycle hooks — which ones actually *act* on a hook later is
        gated by the react_to_create/update/delete config flags, checked in
        hooks_handler. We always register for all three regardless of those
        flags so toggling them in the UI doesn't require a re-registration.
        """
        hooks = [
            "on_postload_ioc_create",
            "on_postload_ioc_update",
            "on_postload_ioc_delete",
        ]

        for hook_name in hooks:
            status = self.register_to_hook(module_id, iris_hook_name=hook_name)

            if status.is_failure():
                self.log.error(f"Failed to register to {hook_name}: {status.get_message()}")
            else:
                self.log.info(f"Registered to {hook_name}")

    def hooks_handler(self, hook_name: str, hook_ui_name: str, data):
        """
        Called by IRIS each time one of our registered hooks fires.

        data is a list of SQLAlchemy Ioc objects for all three hooks we
        subscribed to (on_postload_ioc_create/update/delete) — per IRIS's
        hook documentation, on_postload hooks receive committed objects,
        not raw request payloads.

        We must return data unchanged in the same shape we received it,
        wrapped in an IrisInterfaceStatus — IRIS expects this even though
        we aren't modifying the IOC objects themselves (we only read from
        them to maintain an external file).
        """
        conf = self._dict_conf
        output_dir = conf.get("yara_output_dir")

        if not output_dir:
            self.log.error("yara_output_dir is not configured — module cannot run")
            return IrisInterfaceStatus.I2Error(
                "yara_output_dir not configured", data=data, logs=list(self.message_queue)
            )

        try:
            if hook_name == "on_postload_ioc_create" and conf.get("react_to_create"):
                self._handle_upsert(data, output_dir, hook_name)

            elif hook_name == "on_postload_ioc_update" and conf.get("react_to_update"):
                self._handle_upsert(data, output_dir, hook_name)

            elif hook_name == "on_postload_ioc_delete" and conf.get("react_to_delete"):
                self._handle_delete(data, output_dir, hook_name)

            else:
                self.log.info(f"Ignoring {hook_name} (disabled in module configuration)")

        except Exception as e:
            self.log.error(f"Unhandled error processing {hook_name}: {e}")
            return IrisInterfaceStatus.I2Error(
                f"Unhandled error: {e}", data=data, logs=list(self.message_queue)
            )

        return IrisInterfaceStatus.I2Success(data=data, logs=list(self.message_queue))

    # ── Internal handlers ────────────────────────────────────────────────────

    def _handle_upsert(self, iocs, output_dir: str, hook_name: str):
        """Add or refresh the YARA rule for each IOC in the batch, in every
        case it's linked to (an Ioc row is global and can be linked to more
        than one case via the ioc_link table — see _resolve_cases)."""
        for ioc in iocs:
            ioc_value = getattr(ioc, "ioc_value", None)
            ioc_id = getattr(ioc, "ioc_id", None)

            if not ioc_value or ioc_id is None:
                self.log.warning(f"[{hook_name}] Skipping IOC with missing value or id")
                continue

            ioc_description = getattr(ioc, "ioc_description", "") or ""
            ioc_type = self._resolve_type_name(ioc)
            cases = self._resolve_cases(ioc_id)

            if not cases:
                self.log.warning(
                    f"[{hook_name}] IOC #{ioc_id} ({ioc_value}) has no linked case in "
                    f"ioc_link — skipping, nothing to attribute the rule to"
                )
                continue

            for case_id, case_name in cases:
                path = bundle_writer.upsert_ioc(
                    output_dir=output_dir,
                    case_id=case_id,
                    case_name=case_name,
                    ioc_id=ioc_id,
                    ioc_value=ioc_value,
                    ioc_description=ioc_description,
                    ioc_type=ioc_type,
                )
                self.log.info(
                    f"[{hook_name}] Wrote rule for IOC #{ioc_id} ({ioc_type}: {ioc_value}) "
                    f"case={case_name} -> {path}"
                )

    def _handle_delete(self, iocs, output_dir: str, hook_name: str):
        """
        Remove the YARA rule for each deleted IOC, in every case bundle it
        could have appeared in.

        Note: by the time on_postload_ioc_delete fires, the IOC (and its
        ioc_link rows) are already gone from the DB — so we can't query
        ioc_link here the way _handle_upsert does. We rely on
        bundle_writer.remove_ioc being told a case explicitly, which means
        for a deleted IOC linked to N cases, IRIS must give us a way to know
        which case the delete happened in. See note in hooks_handler / the
        module README about this limitation — for now we scan every existing
        bundle file in output_dir and strip the IOC_ID block from each,
        which is correct regardless of which case(s) the IOC was in.
        """
        for ioc in iocs:
            ioc_id = getattr(ioc, "ioc_id", None)
            if ioc_id is None:
                self.log.warning(f"[{hook_name}] Skipping deleted IOC with no id")
                continue

            removed_paths = bundle_writer.remove_ioc_from_all_bundles(
                output_dir=output_dir, ioc_id=ioc_id
            )
            if removed_paths:
                for path in removed_paths:
                    self.log.info(f"[{hook_name}] Removed rule for IOC #{ioc_id} from {path}")
            else:
                self.log.info(f"[{hook_name}] No bundle contained IOC #{ioc_id}; nothing to remove")

    @staticmethod
    def _resolve_cases(ioc_id) -> list:
        """
        Return [(case_id, case_name), ...] for every case this IOC is linked
        to, by querying the ioc_link join table directly.

        Confirmed against a live IRIS v2.4.27 instance: the Ioc SQLAlchemy
        model has NO case/case_id attribute of its own — an Ioc row is
        global and is linked to one or more cases via a separate ioc_link
        table (columns: ioc_link_id, ioc_id, case_id). The cases table's
        name column is `name`, not `case_name` (that field name only shows
        up in IRIS's Jinja report-template context, not on the raw model).

        This was reached by direct inspection (see module README's
        "Verifying against your IRIS version" section) rather than assumed
        from documentation, since the public docs don't document this join
        table's existence.
        """
        rows = db.session.execute(
            text("""
                SELECT c.case_id, c.name
                FROM ioc_link il
                JOIN cases c ON c.case_id = il.case_id
                WHERE il.ioc_id = :ioc_id
            """),
            {"ioc_id": ioc_id},
        ).fetchall()

        return [(row[0], row[1] or f"case_{row[0]}") for row in rows]

    @staticmethod
    def _resolve_type_name(ioc) -> str:
        """
        Extract a human-readable IOC type string.

        Confirmed against a live instance: ioc.ioc_type is an IocType
        relationship object, and its readable name is at
        ioc.ioc_type.type_name (e.g. "ip-src", "domain", "md5") — NOT a
        direct ioc.type_name attribute, which doesn't exist on Ioc itself.
        """
        ioc_type_obj = getattr(ioc, "ioc_type", None)
        if ioc_type_obj is not None:
            type_name = getattr(ioc_type_obj, "type_name", None)
            if type_name:
                return type_name

        return "unknown"
