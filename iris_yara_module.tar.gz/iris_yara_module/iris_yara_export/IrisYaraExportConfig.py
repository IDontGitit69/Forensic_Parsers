# Import the module types list, so we can indicate the type of our module
from iris_interface.IrisModuleInterface import IrisModuleTypes

# Human name displayed in the GUI Manage > Modules.
module_name = "IrisYaraExport"

# Description displayed when editing the module configuration in the UI.
module_description = (
    "Automatically maintains a per-case YARA rule bundle from case IOCs. "
    "Each IOC create/update/delete is reflected in the bundle file so it "
    "stays in sync without manual exports. Intended to be picked up by an "
    "external scanner (e.g. THOR Lite) reading from the configured output directory."
)

# Interface version this module was built against (matches IrisModuleInterface
# package version — server refuses to load the module if unsupported).
interface_version = 1.2

# Version of this module itself
module_version = 1.0

# This is a processor module — it reacts to IOC hooks, it does not provide
# a file-upload pipeline.
module_type = IrisModuleTypes.module_processor

# Processor modules don't support pipelines
pipeline_support = False
pipeline_info = {}

# Configuration fields shown to admins in Manage > Modules > IrisYaraExport
module_configuration = [
    {
        "param_name": "yara_output_dir",
        "param_human_name": "YARA output directory",
        "param_description": (
            "Directory where per-case .yar bundle files are written. "
            "Point this at the directory your scanner (e.g. THOR Lite's "
            "custom-signatures directory) reads rules from. Must be "
            "writable by the IRIS worker process."
        ),
        "default": "/iris_data/yara_export",
        "mandatory": True,
        "type": "string",
    },
    {
        "param_name": "react_to_create",
        "param_human_name": "Update bundle on IOC create",
        "param_description": "Add a rule to the case's bundle whenever a new IOC is created.",
        "default": True,
        "mandatory": True,
        "type": "bool",
    },
    {
        "param_name": "react_to_update",
        "param_human_name": "Update bundle on IOC update",
        "param_description": "Replace the corresponding rule whenever an existing IOC is edited.",
        "default": True,
        "mandatory": True,
        "type": "bool",
    },
    {
        "param_name": "react_to_delete",
        "param_human_name": "Update bundle on IOC delete",
        "param_description": "Remove the corresponding rule whenever an IOC is deleted from the case.",
        "default": True,
        "mandatory": True,
        "type": "bool",
    },
]
