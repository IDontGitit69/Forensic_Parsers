# Set the __iris_module_interface variable to the name of our main class.
# IRIS looks for "module.__iris_module_interface" then instantiates
# "<that name>.<that name>" — here 'IrisYaraExportModule.IrisYaraExportModule'.
# The file IrisYaraExportModule.py must contain a class of the same name.

__iris_module_interface = "IrisYaraExportModule"
