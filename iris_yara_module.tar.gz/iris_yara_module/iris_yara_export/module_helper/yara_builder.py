#!/usr/bin/env python3
"""
yara_builder.py — IOC -> YARA rule conversion.

This is the same detection/build logic from the original iris_ioc_to_yara.py
script, unchanged, just relocated as a module_helper so the processor module
can call it directly in-process instead of shelling out to a script.
"""

import re
import socket


def sanitize_rule_name(value: str) -> str:
    """Turn an IOC value into a valid YARA rule name."""
    name = re.sub(r"[^a-zA-Z0-9_]", "_", value)
    name = re.sub(r"_+", "_", name).strip("_")
    return f"IOC_{name}"


def is_ipv4(value: str) -> bool:
    try:
        socket.inet_pton(socket.AF_INET, value)
        return True
    except OSError:
        return False


def is_ipv6(value: str) -> bool:
    try:
        socket.inet_pton(socket.AF_INET6, value)
        return True
    except OSError:
        return False


def is_domain(value: str) -> bool:
    domain_re = re.compile(
        r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$"
    )
    return bool(domain_re.match(value))


def is_md5(value: str) -> bool:
    return bool(re.match(r"^[a-fA-F0-9]{32}$", value))


def is_sha1(value: str) -> bool:
    return bool(re.match(r"^[a-fA-F0-9]{40}$", value))


def is_sha256(value: str) -> bool:
    return bool(re.match(r"^[a-fA-F0-9]{64}$", value))


def is_url(value: str) -> bool:
    return value.startswith(("http://", "https://", "ftp://"))


def ipv4_to_hex(ip: str) -> str:
    packed = socket.inet_aton(ip)
    return " ".join(f"{b:02X}" for b in packed)


def ipv6_to_hex(ip: str) -> str:
    packed = socket.inet_pton(socket.AF_INET6, ip)
    return " ".join(f"{b:02X}" for b in packed)


def build_yara_rule(ioc_value: str, ioc_description: str, ioc_type: str) -> str:
    """Build a single YARA rule for one IOC. Identical logic to the original script."""
    rule_name = sanitize_rule_name(ioc_value)
    desc_escaped = (ioc_description or "No description provided.").replace('"', "'")
    ioc_type_lower = (ioc_type or "").lower()

    strings_block = []
    condition_parts = []

    if is_ipv4(ioc_value) or "ip" in ioc_type_lower:
        if is_ipv4(ioc_value):
            hex_bytes = ipv4_to_hex(ioc_value)
            strings_block.append(f'        $ip_ascii   = "{ioc_value}"')
            strings_block.append(f'        $ip_wide    = "{ioc_value}" wide')
            strings_block.append(f'        $ip_bin     = {{ {hex_bytes} }}')
            condition_parts.append("any of ($ip_ascii, $ip_wide, $ip_bin)")

    elif is_ipv6(ioc_value):
        hex_bytes = ipv6_to_hex(ioc_value)
        strings_block.append(f'        $ip6_ascii  = "{ioc_value}"')
        strings_block.append(f'        $ip6_wide   = "{ioc_value}" wide')
        strings_block.append(f'        $ip6_bin    = {{ {hex_bytes} }}')
        condition_parts.append("any of ($ip6_ascii, $ip6_wide, $ip6_bin)")

    elif is_domain(ioc_value) or "domain" in ioc_type_lower or "hostname" in ioc_type_lower:
        strings_block.append(f'        $domain_ascii = "{ioc_value}" nocase')
        strings_block.append(f'        $domain_wide  = "{ioc_value}" wide nocase')
        condition_parts.append("any of ($domain_ascii, $domain_wide)")

    elif is_url(ioc_value) or "url" in ioc_type_lower:
        safe_val = ioc_value.replace("\\", "\\\\").replace('"', '\\"')
        strings_block.append(f'        $url_ascii  = "{safe_val}" nocase')
        strings_block.append(f'        $url_wide   = "{safe_val}" wide nocase')
        condition_parts.append("any of ($url_ascii, $url_wide)")

    elif is_md5(ioc_value) or "md5" in ioc_type_lower:
        strings_block.append(f'        $md5_ascii  = "{ioc_value}" nocase')
        strings_block.append(f'        $md5_wide   = "{ioc_value}" wide nocase')
        condition_parts.append("any of ($md5_ascii, $md5_wide)")

    elif is_sha1(ioc_value) or "sha1" in ioc_type_lower:
        strings_block.append(f'        $sha1_ascii = "{ioc_value}" nocase')
        strings_block.append(f'        $sha1_wide  = "{ioc_value}" wide nocase')
        condition_parts.append("any of ($sha1_ascii, $sha1_wide)")

    elif is_sha256(ioc_value) or "sha256" in ioc_type_lower:
        strings_block.append(f'        $sha256_ascii = "{ioc_value}" nocase')
        strings_block.append(f'        $sha256_wide  = "{ioc_value}" wide nocase')
        condition_parts.append("any of ($sha256_ascii, $sha256_wide)")

    else:
        safe_val = ioc_value.replace("\\", "\\\\").replace('"', '\\"')
        strings_block.append(f'        $str_ascii  = "{safe_val}" nocase')
        strings_block.append(f'        $str_wide   = "{safe_val}" wide nocase')
        condition_parts.append("any of ($str_ascii, $str_wide)")

    strings_section = "\n".join(strings_block)
    condition_section = " or\n        ".join(condition_parts)

    return f"""rule {rule_name}
{{
    meta:
        description = "{desc_escaped}"
        ioc_type    = "{ioc_type}"
        ioc_value   = "{ioc_value}"

    strings:
{strings_section}

    condition:
        {condition_section}
}}
"""
