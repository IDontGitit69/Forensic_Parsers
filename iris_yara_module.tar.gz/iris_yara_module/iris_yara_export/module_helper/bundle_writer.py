#!/usr/bin/env python3
"""
bundle_writer.py — Maintains a per-case .yar bundle file as IOCs change.

Unlike the original iris_ioc_to_yara.py (which always regenerates a bundle
from scratch by listing every IOC in a case), this module is event-driven:
it's notified one IOC at a time, on create/update/delete, and has to keep an
existing file in sync rather than rebuild it wholesale every time.

Strategy: each rule block is tagged with an HTML-style comment carrying the
IOC's ID, e.g.:

    // IOC_ID:482
    rule IOC_185_199_110_153 {
        ...
    }

This makes individual rules addressable for replacement (update) or removal
(delete) via simple text parsing, without needing a database of our own —
the file itself is the source of truth, same philosophy as the original
script's single-shot bundle.
"""

import re
from pathlib import Path
from threading import Lock
from typing import Optional

from .yara_builder import build_yara_rule

# One process-wide lock since hooks can fire concurrently (e.g. several
# analysts adding IOCs at once) and we do read-modify-write on the same file.
_write_lock = Lock()

_BLOCK_RE_TEMPLATE = r"// IOC_ID:{ioc_id}\nrule [^\{{]+\{{.*?\n\}}\n"


def _bundle_path(output_dir: str, case_id, case_name: str) -> Path:
    safe_name = re.sub(r"[^a-zA-Z0-9_]", "_", case_name or f"case_{case_id}")
    safe_name = re.sub(r"_+", "_", safe_name).strip("_")
    return Path(output_dir) / f"{safe_name}.yar"


def _bundle_header(case_id, case_name: str) -> str:
    return (
        f"// YARA Rule Bundle\n"
        f"// Case: {case_name} (id={case_id})\n"
        f"// Maintained automatically by IrisYaraExport module — do not edit by hand,\n"
        f"// changes will be overwritten on the next IOC create/update/delete.\n\n"
    )


def upsert_ioc(output_dir: str, case_id, case_name: str, ioc_id, ioc_value: str,
               ioc_description: str, ioc_type: str) -> Path:
    """
    Add or replace the rule block for one IOC in the case's bundle file.
    Creates the bundle (with header) if it doesn't exist yet.
    """
    path = _bundle_path(output_dir, case_id, case_name)
    rule_body = build_yara_rule(ioc_value, ioc_description, ioc_type)
    tagged_block = f"// IOC_ID:{ioc_id}\n{rule_body}"

    with _write_lock:
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            content = path.read_text()
        else:
            content = _bundle_header(case_id, case_name)

        pattern = re.compile(_BLOCK_RE_TEMPLATE.format(ioc_id=re.escape(str(ioc_id))),
                              re.DOTALL)

        if pattern.search(content):
            # Update: replace the existing block in place
            content = pattern.sub(tagged_block, content)
        else:
            # Create: append a new block
            if not content.endswith("\n\n"):
                content = content.rstrip("\n") + "\n\n"
            content += tagged_block + "\n"

        path.write_text(content)

    return path


def remove_ioc(output_dir: str, case_id, case_name: str, ioc_id) -> Optional[Path]:
    """
    Remove one IOC's rule block from the case's bundle file.
    Returns the bundle path if it exists, else None (nothing to do).
    """
    path = _bundle_path(output_dir, case_id, case_name)

    with _write_lock:
        if not path.exists():
            return None

        content = path.read_text()
        pattern = re.compile(_BLOCK_RE_TEMPLATE.format(ioc_id=re.escape(str(ioc_id))),
                              re.DOTALL)
        new_content = pattern.sub("", content)

        if new_content != content:
            path.write_text(new_content)

    return path


def remove_ioc_from_all_bundles(output_dir: str, ioc_id) -> list:
    """
    Remove one IOC's rule block from every .yar bundle file in output_dir.

    Used for delete handling: by the time on_postload_ioc_delete fires, the
    IOC's row (and its ioc_link entries) are already gone from the DB, so we
    can no longer query which case(s) it belonged to the way upsert_ioc's
    caller does. Scanning every bundle for a matching // IOC_ID: tag is the
    only way to find and remove the right block(s) without that information.

    Returns the list of bundle paths that were actually modified.
    """
    out_dir = Path(output_dir)
    if not out_dir.exists():
        return []

    pattern = re.compile(_BLOCK_RE_TEMPLATE.format(ioc_id=re.escape(str(ioc_id))),
                          re.DOTALL)
    modified = []

    with _write_lock:
        for bundle_file in out_dir.glob("*.yar"):
            content = bundle_file.read_text()
            new_content = pattern.sub("", content)
            if new_content != content:
                bundle_file.write_text(new_content)
                modified.append(bundle_file)

    return modified


def count_rules(output_dir: str, case_id, case_name: str) -> int:
    """How many IOC rule blocks currently exist in this case's bundle."""
    path = _bundle_path(output_dir, case_id, case_name)
    if not path.exists():
        return 0
    return len(re.findall(r"^// IOC_ID:", path.read_text(), re.MULTILINE))
