from setuptools import setup, find_packages

setup(
    name="iris_yara_export",
    version="1.0.0",
    description="DFIR-IRIS processor module: maintains a per-case YARA bundle from case IOCs",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="",
    license="LGPL-3.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        # iris_interface is provided by the IRIS server environment itself
        # when the module is loaded — not pip-installed standalone.
    ],
    python_requires=">=3.9",
)
